import type { MouseEventHandler, ReactNode } from "react";
export interface SidebarItem {
    id: string;
    label: string;
    icon?: ReactNode;
    href?: string;
    onClick?: MouseEventHandler<HTMLAnchorElement | HTMLButtonElement>;
    disabled?: boolean;
}
export interface SidebarGroup {
    id: string;
    label?: string;
    items: SidebarItem[];
}
export interface SidebarProps {
    groups: SidebarGroup[];
    activeItemId?: string;
    collapsed?: boolean;
    onCollapsedChange?: (collapsed: boolean) => void;
    header?: ReactNode;
    footer?: ReactNode;
    className?: string;
}
export declare function Sidebar({ groups, activeItemId, collapsed, onCollapsedChange, header, footer, className, }: SidebarProps): import("react").JSX.Element;
