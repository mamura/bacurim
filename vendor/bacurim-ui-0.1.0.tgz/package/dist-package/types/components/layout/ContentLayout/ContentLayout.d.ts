import type { ReactNode } from 'react';
export type ContentLayoutWidth = 'constrained' | 'wide' | 'fluid';
export interface ContentLayoutProps {
    children: ReactNode;
    width?: ContentLayoutWidth;
    className?: string;
}
export declare function ContentLayout({ children, width, className, }: ContentLayoutProps): import("react").JSX.Element;
