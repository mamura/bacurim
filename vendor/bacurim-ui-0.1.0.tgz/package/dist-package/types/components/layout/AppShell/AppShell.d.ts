import type { ReactNode } from 'react';
export interface AppShellProps {
    navigation?: ReactNode;
    header?: ReactNode;
    children: ReactNode;
    className?: string;
    mobileNavigationOpen?: boolean;
    onMobileNavigationOpenChange?: (open: boolean) => void;
}
export declare function AppShell({ navigation, header, children, className, mobileNavigationOpen, onMobileNavigationOpenChange, }: AppShellProps): import("react").JSX.Element;
