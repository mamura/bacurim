import type { ReactNode } from "react";
export interface HeaderProps {
    logo: ReactNode;
    navigation?: ReactNode;
    actions?: ReactNode;
    className?: string;
}
export declare function Header({ logo, navigation, actions, className, }: HeaderProps): import("react").JSX.Element;
