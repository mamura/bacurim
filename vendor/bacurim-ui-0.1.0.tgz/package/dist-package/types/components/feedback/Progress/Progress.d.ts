import { type HTMLAttributes } from 'react';
import './progress.css';
export type ProgressColor = 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'info';
export type ProgressSize = 'sm' | 'md' | 'lg';
export type ProgressRadius = 'none' | 'sm' | 'md' | 'full';
export type ProgressLabelPosition = 'top' | 'end' | 'inside' | 'floating';
export type ProgressValueFormat = 'percentage' | 'value';
export interface ProgressProps extends Omit<HTMLAttributes<HTMLDivElement>, 'color'> {
    value?: number;
    min?: number;
    max?: number;
    indeterminate?: boolean;
    color?: ProgressColor;
    size?: ProgressSize;
    radius?: ProgressRadius;
    label?: string;
    showValue?: boolean;
    labelPosition?: ProgressLabelPosition;
    valueFormat?: ProgressValueFormat;
}
export declare const Progress: import("react").ForwardRefExoticComponent<ProgressProps & import("react").RefAttributes<HTMLDivElement>>;
