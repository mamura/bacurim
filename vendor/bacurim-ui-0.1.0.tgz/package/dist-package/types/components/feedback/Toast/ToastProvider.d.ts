import { type ReactNode } from 'react';
import { type ToastAction, type ToastAppearance, type ToastVariant } from './Toast';
export type ToastPosition = 'top-left' | 'top-center' | 'top-right' | 'center' | 'bottom-left' | 'bottom-center' | 'bottom-right';
export interface ToastOptions {
    variant?: ToastVariant;
    appearance?: ToastAppearance;
    title?: ReactNode;
    description?: ReactNode;
    icon?: ReactNode;
    action?: ToastAction;
    duration?: number;
    dismissible?: boolean;
    loading?: boolean;
    progress?: number;
}
export type ToastUpdateOptions = Partial<ToastOptions>;
export interface ToastRecord extends ToastOptions {
    id: string;
    revision: number;
}
export interface ToastApi {
    show: (options: ToastOptions) => string;
    info: (options: ToastOptions) => string;
    success: (options: ToastOptions) => string;
    warning: (options: ToastOptions) => string;
    danger: (options: ToastOptions) => string;
    loading: (options: ToastOptions) => string;
    update: (id: string, options: ToastUpdateOptions) => void;
    dismiss: (id: string) => void;
    dismissAll: () => void;
}
export interface ToastProviderProps {
    children: ReactNode;
    position?: ToastPosition;
    duration?: number;
    maxToasts?: number;
}
export declare function ToastProvider({ children, position, duration, maxToasts, }: ToastProviderProps): import("react").JSX.Element;
export declare function useToast(): ToastApi;
