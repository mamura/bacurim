import { type HTMLAttributes, type ReactNode } from 'react';
export type ToastVariant = 'info' | 'success' | 'warning' | 'danger';
export type ToastAppearance = 'default' | 'soft' | 'solid';
export interface ToastAction {
    label: string;
    onClick: () => void;
}
export interface ToastProps extends Omit<HTMLAttributes<HTMLDivElement>, 'title'> {
    variant?: ToastVariant;
    appearance?: ToastAppearance;
    title?: ReactNode;
    description?: ReactNode;
    icon?: ReactNode;
    loading?: boolean;
    progress?: number;
    action?: ToastAction;
    dismissible?: boolean;
    onDismiss?: () => void;
}
export declare const Toast: import("react").ForwardRefExoticComponent<ToastProps & import("react").RefAttributes<HTMLDivElement>>;
