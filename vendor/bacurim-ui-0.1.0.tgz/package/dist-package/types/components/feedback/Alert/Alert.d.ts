import { type HTMLAttributes, type ReactNode } from 'react';
export type AlertVariant = 'info' | 'success' | 'warning' | 'danger';
export interface AlertProps extends Omit<HTMLAttributes<HTMLDivElement>, 'title'> {
    variant?: AlertVariant;
    dismissible?: boolean;
    onDismiss?: () => void;
}
export interface AlertIconProps extends HTMLAttributes<HTMLSpanElement> {
    children?: ReactNode;
}
export type AlertContentProps = HTMLAttributes<HTMLDivElement>;
export type AlertTitleProps = HTMLAttributes<HTMLHeadingElement>;
export type AlertDescriptionProps = HTMLAttributes<HTMLParagraphElement>;
export type AlertActionsProps = HTMLAttributes<HTMLDivElement>;
export declare const Alert: import("react").ForwardRefExoticComponent<AlertProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const AlertIcon: import("react").ForwardRefExoticComponent<AlertIconProps & import("react").RefAttributes<HTMLSpanElement>>;
export declare const AlertContent: import("react").ForwardRefExoticComponent<AlertContentProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const AlertTitle: import("react").ForwardRefExoticComponent<AlertTitleProps & import("react").RefAttributes<HTMLHeadingElement>>;
export declare const AlertDescription: import("react").ForwardRefExoticComponent<AlertDescriptionProps & import("react").RefAttributes<HTMLParagraphElement>>;
export declare const AlertActions: import("react").ForwardRefExoticComponent<AlertActionsProps & import("react").RefAttributes<HTMLDivElement>>;
