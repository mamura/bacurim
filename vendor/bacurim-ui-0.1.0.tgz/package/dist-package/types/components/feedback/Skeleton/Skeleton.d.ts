import { type CSSProperties, type HTMLAttributes } from 'react';
import './skeleton.css';
export type SkeletonVariant = 'text' | 'rectangle' | 'rounded' | 'circle';
export type SkeletonAnimation = 'pulse' | 'wave' | 'none';
export interface SkeletonProps extends Omit<HTMLAttributes<HTMLSpanElement>, 'children'> {
    variant?: SkeletonVariant;
    animation?: SkeletonAnimation;
    width?: CSSProperties['width'];
    height?: CSSProperties['height'];
}
export declare const Skeleton: import("react").ForwardRefExoticComponent<SkeletonProps & import("react").RefAttributes<HTMLSpanElement>>;
