import { type HTMLAttributes } from 'react';
export type EmptyStateSize = 'sm' | 'md' | 'lg';
export interface EmptyStateProps extends HTMLAttributes<HTMLDivElement> {
    size?: EmptyStateSize;
}
export type EmptyStateIconProps = HTMLAttributes<HTMLDivElement>;
export type EmptyStateTitleProps = HTMLAttributes<HTMLHeadingElement>;
export type EmptyStateDescriptionProps = HTMLAttributes<HTMLParagraphElement>;
export type EmptyStateActionsProps = HTMLAttributes<HTMLDivElement>;
export declare const EmptyState: import("react").ForwardRefExoticComponent<EmptyStateProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const EmptyStateIcon: import("react").ForwardRefExoticComponent<EmptyStateIconProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const EmptyStateTitle: import("react").ForwardRefExoticComponent<EmptyStateTitleProps & import("react").RefAttributes<HTMLHeadingElement>>;
export declare const EmptyStateDescription: import("react").ForwardRefExoticComponent<EmptyStateDescriptionProps & import("react").RefAttributes<HTMLParagraphElement>>;
export declare const EmptyStateActions: import("react").ForwardRefExoticComponent<EmptyStateActionsProps & import("react").RefAttributes<HTMLDivElement>>;
