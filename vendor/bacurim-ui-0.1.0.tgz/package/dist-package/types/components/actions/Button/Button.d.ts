import type { ButtonHTMLAttributes, ReactNode } from 'react';
export type ButtonVariant = 'solid' | 'outline' | 'ghost' | 'soft' | 'white' | 'link';
export type ButtonColor = 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'info' | 'neutral';
export type ButtonSize = 'sm' | 'md' | 'lg';
export type ButtonRadius = 'sm' | 'md' | 'lg' | 'full';
export interface ButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'color'> {
    variant?: ButtonVariant;
    color?: ButtonColor;
    size?: ButtonSize;
    radius?: ButtonRadius;
    fullWidth?: boolean;
    loading?: boolean;
    loadingText?: string;
    startIcon?: ReactNode;
    endIcon?: ReactNode;
    iconOnly?: boolean;
}
export declare function Button({ variant, color, size, radius, fullWidth, loading, loadingText, startIcon, endIcon, iconOnly, disabled, type, className, children, ...props }: ButtonProps): import("react").JSX.Element;
