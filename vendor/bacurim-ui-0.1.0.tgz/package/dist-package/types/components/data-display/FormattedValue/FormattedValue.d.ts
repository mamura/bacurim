import { type HTMLAttributes } from 'react';
import { type NullableNumber, type DateValue, type NumberFormatOptions, type CurrencyFormatOptions, type PercentageFormatOptions, type DateFormatOptions } from '../../../utilities/formatters';
type BaseProps = Omit<HTMLAttributes<HTMLSpanElement>, 'children'>;
export type FormattedValueProps = (BaseProps & {
    type: 'number';
    value: NullableNumber;
    options?: NumberFormatOptions;
}) | (BaseProps & {
    type: 'currency';
    value: NullableNumber;
    options?: CurrencyFormatOptions;
}) | (BaseProps & {
    type: 'percentage';
    value: NullableNumber;
    options?: PercentageFormatOptions;
}) | (BaseProps & {
    type: 'date';
    value: DateValue;
    options?: DateFormatOptions;
});
export declare const FormattedValue: import("react").ForwardRefExoticComponent<FormattedValueProps & import("react").RefAttributes<HTMLSpanElement>>;
export {};
