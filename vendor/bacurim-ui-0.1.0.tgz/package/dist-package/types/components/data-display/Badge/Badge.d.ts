import { type HTMLAttributes, type ReactNode } from 'react';
export type BadgeVariant = 'solid' | 'soft' | 'outline' | 'white';
export type BadgeColor = 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'info' | 'neutral';
export type BadgeSize = 'sm' | 'md' | 'lg';
export type BadgeRadius = 'sm' | 'md' | 'lg' | 'full';
export interface BadgeProps extends Omit<HTMLAttributes<HTMLSpanElement>, 'color'> {
    variant?: BadgeVariant;
    color?: BadgeColor;
    size?: BadgeSize;
    radius?: BadgeRadius;
    startIcon?: ReactNode;
    endIcon?: ReactNode;
    dot?: boolean;
    truncate?: boolean;
}
export declare const Badge: import("react").ForwardRefExoticComponent<BadgeProps & import("react").RefAttributes<HTMLSpanElement>>;
