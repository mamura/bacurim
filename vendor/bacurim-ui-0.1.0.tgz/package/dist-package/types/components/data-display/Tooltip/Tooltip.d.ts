import { type ComponentPropsWithoutRef } from 'react';
import * as TooltipPrimitive from '@radix-ui/react-tooltip';
export type TooltipVariant = 'default' | 'light' | 'primary';
export declare const TooltipProvider: import("react").FC<TooltipPrimitive.TooltipProviderProps>;
export declare const Tooltip: import("react").FC<TooltipPrimitive.TooltipProps>;
export declare const TooltipTrigger: import("react").ForwardRefExoticComponent<TooltipPrimitive.TooltipTriggerProps & import("react").RefAttributes<HTMLButtonElement>>;
export interface TooltipContentProps extends ComponentPropsWithoutRef<typeof TooltipPrimitive.Content> {
    variant?: TooltipVariant;
    arrow?: boolean;
}
export declare const TooltipContent: import("react").ForwardRefExoticComponent<TooltipContentProps & import("react").RefAttributes<HTMLDivElement>>;
