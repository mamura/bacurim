import { type HTMLAttributes, type TableHTMLAttributes, type ThHTMLAttributes, type TdHTMLAttributes } from 'react';
export type TableDensity = 'compact' | 'default' | 'comfortable';
export type TableVariant = 'default' | 'bordered';
export type TableColor = 'neutral' | 'success' | 'warning' | 'error' | 'info';
export type TableAlign = 'left' | 'center' | 'right';
export interface TableProps extends TableHTMLAttributes<HTMLTableElement> {
    density?: TableDensity;
    variant?: TableVariant;
    striped?: boolean;
    stripeColor?: TableColor;
    hoverable?: boolean;
    hoverColor?: TableColor;
}
export type TableHeaderProps = HTMLAttributes<HTMLTableSectionElement>;
export type TableBodyProps = HTMLAttributes<HTMLTableSectionElement>;
export type TableFooterProps = HTMLAttributes<HTMLTableSectionElement>;
export interface TableRowProps extends HTMLAttributes<HTMLTableRowElement> {
    selected?: boolean;
    highlight?: TableColor;
    interactive?: boolean;
}
export interface TableHeadProps extends ThHTMLAttributes<HTMLTableCellElement> {
    align?: TableAlign;
    highlight?: TableColor;
}
export interface TableCellProps extends TdHTMLAttributes<HTMLTableCellElement> {
    align?: TableAlign;
    highlight?: TableColor;
}
export type TableCaptionProps = HTMLAttributes<HTMLTableCaptionElement>;
export declare const Table: import("react").ForwardRefExoticComponent<TableProps & import("react").RefAttributes<HTMLTableElement>>;
export declare const TableHeader: import("react").ForwardRefExoticComponent<TableHeaderProps & import("react").RefAttributes<HTMLTableSectionElement>>;
export declare const TableBody: import("react").ForwardRefExoticComponent<TableBodyProps & import("react").RefAttributes<HTMLTableSectionElement>>;
export declare const TableFooter: import("react").ForwardRefExoticComponent<TableFooterProps & import("react").RefAttributes<HTMLTableSectionElement>>;
export declare const TableRow: import("react").ForwardRefExoticComponent<TableRowProps & import("react").RefAttributes<HTMLTableRowElement>>;
export declare const TableHead: import("react").ForwardRefExoticComponent<TableHeadProps & import("react").RefAttributes<HTMLTableCellElement>>;
export declare const TableCell: import("react").ForwardRefExoticComponent<TableCellProps & import("react").RefAttributes<HTMLTableCellElement>>;
export declare const TableCaption: import("react").ForwardRefExoticComponent<TableCaptionProps & import("react").RefAttributes<HTMLTableCaptionElement>>;
