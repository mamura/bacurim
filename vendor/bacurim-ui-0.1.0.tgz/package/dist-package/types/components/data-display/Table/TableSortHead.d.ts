import { type ReactNode } from 'react';
import { type TableHeadProps } from './Table';
export type TableSortDirection = 'asc' | 'desc' | null;
export interface TableSortHeadProps extends Omit<TableHeadProps, 'children' | 'onClick' | 'onKeyDown'> {
    children: ReactNode;
    sortDirection?: TableSortDirection;
    onSortChange?: (direction: TableSortDirection) => void;
    allowUnsort?: boolean;
    disabled?: boolean;
}
export declare function getNextSortDirection(current: TableSortDirection, allowUnsort?: boolean): TableSortDirection;
export declare const TableSortHead: import("react").ForwardRefExoticComponent<TableSortHeadProps & import("react").RefAttributes<HTMLTableCellElement>>;
