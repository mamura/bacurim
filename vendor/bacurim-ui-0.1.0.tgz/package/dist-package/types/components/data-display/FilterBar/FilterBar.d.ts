import { type HTMLAttributes, type ReactNode } from 'react';
export interface FilterBarProps extends HTMLAttributes<HTMLDivElement> {
    activeFiltersCount?: number;
    onClear?: () => void;
    clearLabel?: string;
    showClearButton?: boolean;
    showActiveCount?: boolean;
    title?: string;
    children: ReactNode;
}
export declare const FilterBar: import("react").ForwardRefExoticComponent<FilterBarProps & import("react").RefAttributes<HTMLDivElement>>;
export interface FilterBarContentProps extends HTMLAttributes<HTMLDivElement> {
    columns?: 1 | 2 | 3 | 4;
    children: ReactNode;
}
export declare const FilterBarContent: import("react").ForwardRefExoticComponent<FilterBarContentProps & import("react").RefAttributes<HTMLDivElement>>;
export interface FilterBarActionsProps extends HTMLAttributes<HTMLDivElement> {
    align?: 'start' | 'center' | 'end';
    children: ReactNode;
}
export declare const FilterBarActions: import("react").ForwardRefExoticComponent<FilterBarActionsProps & import("react").RefAttributes<HTMLDivElement>>;
