import { type TextareaHTMLAttributes } from 'react';
export type TextareaSize = 'sm' | 'md' | 'lg';
export type TextareaRadius = 'sm' | 'md' | 'lg';
export type TextareaResize = 'none' | 'vertical' | 'horizontal' | 'both';
export interface TextareaProps extends Omit<TextareaHTMLAttributes<HTMLTextAreaElement>, 'size'> {
    size?: TextareaSize;
    radius?: TextareaRadius;
    resize?: TextareaResize;
    invalid?: boolean;
}
export declare const Textarea: import("react").ForwardRefExoticComponent<TextareaProps & import("react").RefAttributes<HTMLTextAreaElement>>;
