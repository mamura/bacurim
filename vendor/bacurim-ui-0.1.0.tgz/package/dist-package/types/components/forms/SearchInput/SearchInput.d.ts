import { type InputProps } from '../Input';
export interface SearchInputProps extends Omit<InputProps, 'type' | 'startIcon' | 'endIcon' | 'endAdornment'> {
    clearable?: boolean;
    onClear?: () => void;
    clearLabel?: string;
}
export declare const SearchInput: import("react").ForwardRefExoticComponent<SearchInputProps & import("react").RefAttributes<HTMLInputElement>>;
