import { type InputHTMLAttributes } from 'react';
export type DateInputSize = 'sm' | 'md' | 'lg';
export type DateInputFormat = 'dd/MM/yyyy' | 'MM/dd/yyyy' | 'yyyy-MM-dd';
export interface DateInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size' | 'value' | 'defaultValue' | 'onChange'> {
    value?: string | null;
    defaultValue?: string | null;
    onValueChange?: (value: string | null) => void;
    format?: DateInputFormat;
    minDate?: string;
    maxDate?: string;
    invalid?: boolean;
    size?: DateInputSize;
}
export declare const DateInput: import("react").ForwardRefExoticComponent<DateInputProps & import("react").RefAttributes<HTMLInputElement>>;
