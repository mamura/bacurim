import { type ComponentPropsWithoutRef } from 'react';
import * as RadioGroupPrimitive from '@radix-ui/react-radio-group';
export type RadioGroupSize = 'sm' | 'md' | 'lg';
export type RadioGroupColor = 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'info';
export type RadioGroupOrientation = 'horizontal' | 'vertical';
export interface RadioGroupProps extends ComponentPropsWithoutRef<typeof RadioGroupPrimitive.Root> {
}
export interface RadioGroupItemProps extends ComponentPropsWithoutRef<typeof RadioGroupPrimitive.Item> {
    size?: RadioGroupSize;
    color?: RadioGroupColor;
}
export declare const RadioGroup: import("react").ForwardRefExoticComponent<RadioGroupProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const RadioGroupItem: import("react").ForwardRefExoticComponent<RadioGroupItemProps & import("react").RefAttributes<HTMLButtonElement>>;
