import { type InputHTMLAttributes, type ReactNode } from 'react';
export type InputSize = 'sm' | 'md' | 'lg';
export type InputRadius = 'sm' | 'md' | 'lg' | 'full';
export type InputType = 'text' | 'email' | 'password' | 'tel' | 'url' | 'search' | 'number';
export interface InputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size' | 'type'> {
    size?: InputSize;
    radius?: InputRadius;
    type?: InputType;
    startIcon?: ReactNode;
    endIcon?: ReactNode;
    endAdornment?: ReactNode;
    invalid?: boolean;
}
export declare const Input: import("react").ForwardRefExoticComponent<InputProps & import("react").RefAttributes<HTMLInputElement>>;
