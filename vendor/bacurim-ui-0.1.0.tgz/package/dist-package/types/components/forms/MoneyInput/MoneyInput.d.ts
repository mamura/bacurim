import { type InputHTMLAttributes } from 'react';
export type MoneyInputSize = 'sm' | 'md' | 'lg';
export interface MoneyInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size' | 'value' | 'defaultValue'> {
    value?: number | null;
    defaultValue?: number | null;
    onValueChange?: (value: number | null) => void;
    currency?: string;
    locale?: string;
    allowNegative?: boolean;
    invalid?: boolean;
    size?: MoneyInputSize;
}
export declare const MoneyInput: import("react").ForwardRefExoticComponent<MoneyInputProps & import("react").RefAttributes<HTMLInputElement>>;
