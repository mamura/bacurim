import { type ComponentPropsWithoutRef, type HTMLAttributes, type LabelHTMLAttributes, type ReactNode } from 'react';
import { Slot } from '@radix-ui/react-slot';
export interface FormFieldProps extends HTMLAttributes<HTMLDivElement> {
    invalid?: boolean;
    required?: boolean;
    children: ReactNode;
}
export declare const FormField: import("react").ForwardRefExoticComponent<FormFieldProps & import("react").RefAttributes<HTMLDivElement>>;
export interface FormFieldLabelProps extends LabelHTMLAttributes<HTMLLabelElement> {
}
export declare const FormFieldLabel: import("react").ForwardRefExoticComponent<FormFieldLabelProps & import("react").RefAttributes<HTMLLabelElement>>;
export interface FormFieldControlProps extends ComponentPropsWithoutRef<typeof Slot> {
}
export declare const FormFieldControl: import("react").ForwardRefExoticComponent<FormFieldControlProps & import("react").RefAttributes<HTMLElement>>;
export interface FormFieldDescriptionProps extends HTMLAttributes<HTMLParagraphElement> {
}
export declare const FormFieldDescription: import("react").ForwardRefExoticComponent<FormFieldDescriptionProps & import("react").RefAttributes<HTMLParagraphElement>>;
export interface FormFieldErrorProps extends HTMLAttributes<HTMLParagraphElement> {
}
export declare const FormFieldError: import("react").ForwardRefExoticComponent<FormFieldErrorProps & import("react").RefAttributes<HTMLParagraphElement>>;
