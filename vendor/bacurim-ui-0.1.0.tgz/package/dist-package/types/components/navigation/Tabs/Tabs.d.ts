import { type ButtonHTMLAttributes, type HTMLAttributes, type ReactNode } from 'react';
export type TabsOrientation = 'horizontal' | 'vertical';
export type TabsVariant = 'underline' | 'pills' | 'segment' | 'card' | 'bar';
export type TabsSize = 'sm' | 'md' | 'lg';
export type TabsAlign = 'start' | 'center' | 'end';
export interface TabsProps extends Omit<HTMLAttributes<HTMLDivElement>, 'defaultValue'> {
    value?: string;
    defaultValue?: string;
    onValueChange?: (value: string) => void;
    orientation?: TabsOrientation;
}
export declare const Tabs: import("react").ForwardRefExoticComponent<TabsProps & import("react").RefAttributes<HTMLDivElement>>;
export interface TabsListProps extends HTMLAttributes<HTMLDivElement> {
    variant?: TabsVariant;
    size?: TabsSize;
    align?: TabsAlign;
    fullWidth?: boolean;
    scrollable?: boolean;
}
export declare const TabsList: import("react").ForwardRefExoticComponent<TabsListProps & import("react").RefAttributes<HTMLDivElement>>;
export interface TabsTriggerProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    value: string;
    children?: ReactNode;
}
export declare const TabsTrigger: import("react").ForwardRefExoticComponent<TabsTriggerProps & import("react").RefAttributes<HTMLButtonElement>>;
export interface TabsContentProps extends HTMLAttributes<HTMLDivElement> {
    value: string;
    forceMount?: boolean;
}
export declare const TabsContent: import("react").ForwardRefExoticComponent<TabsContentProps & import("react").RefAttributes<HTMLDivElement>>;
