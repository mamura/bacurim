import { type HTMLAttributes } from 'react';
export type PaginationSize = 'sm' | 'md' | 'lg';
export type PaginationVariant = 'default' | 'outline';
export type PaginationItem = number | 'start-ellipsis' | 'end-ellipsis';
export interface PaginationProps extends Omit<HTMLAttributes<HTMLElement>, 'onChange'> {
    page: number;
    totalPages: number;
    onPageChange: (page: number) => void;
    siblingCount?: number;
    boundaryCount?: number;
    showFirstLast?: boolean;
    showPreviousNext?: boolean;
    size?: PaginationSize;
    variant?: PaginationVariant;
    disabled?: boolean;
}
export declare function getPaginationItems({ page, totalPages, siblingCount, boundaryCount, }: Pick<PaginationProps, 'page' | 'totalPages' | 'siblingCount' | 'boundaryCount'>): PaginationItem[];
export declare const Pagination: import("react").ForwardRefExoticComponent<PaginationProps & import("react").RefAttributes<HTMLElement>>;
