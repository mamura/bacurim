import type { NullableNumber } from './number';
export interface CurrencyFormatOptions extends Omit<Intl.NumberFormatOptions, 'style' | 'currency'> {
    locale?: string;
    currency?: string;
    fallback?: string;
}
export declare function formatCurrency(value: NullableNumber, { locale, currency, fallback, ...options }?: CurrencyFormatOptions): string;
