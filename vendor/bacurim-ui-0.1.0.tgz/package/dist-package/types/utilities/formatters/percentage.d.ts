import type { NullableNumber } from './number';
export interface PercentageFormatOptions extends Omit<Intl.NumberFormatOptions, 'style'> {
    locale?: string;
    fallback?: string;
}
export declare function formatPercentage(value: NullableNumber, { locale, fallback, ...options }?: PercentageFormatOptions): string;
