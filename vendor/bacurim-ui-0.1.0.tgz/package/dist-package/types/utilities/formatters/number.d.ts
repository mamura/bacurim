export type NullableNumber = number | null | undefined;
export interface NumberFormatOptions extends Intl.NumberFormatOptions {
    locale?: string;
    fallback?: string;
}
export declare function formatNumber(value: NullableNumber, { locale, fallback, ...options }?: NumberFormatOptions): string;
