export type DateValue = Date | string | number | null | undefined;
export interface DateFormatOptions extends Intl.DateTimeFormatOptions {
    locale?: string;
    fallback?: string;
}
export declare function formatDate(value: DateValue, { locale, fallback, ...options }?: DateFormatOptions): string;
