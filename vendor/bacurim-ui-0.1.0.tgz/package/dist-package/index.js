"use client";
import { createContext, forwardRef, useCallback, useContext, useEffect, useId, useImperativeHandle, useRef, useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { twMerge } from "tailwind-merge";
import * as DropdownMenuPrimitive from "@radix-ui/react-dropdown-menu";
import * as TooltipPrimitive from "@radix-ui/react-tooltip";
import * as AvatarPrimitive from "@radix-ui/react-avatar";
import * as SeparatorPrimitive from "@radix-ui/react-separator";
import * as SelectPrimitive from "@radix-ui/react-select";
import { ArrowDown, ArrowUp, ArrowUpDown, CalendarDays, Check, CheckCircle2, ChevronDown, ChevronLeft, ChevronRight, ChevronUp, ChevronsLeft, ChevronsRight, CircleAlert, Info, LoaderCircle, Minus, RotateCcw, Search, TriangleAlert, X } from "lucide-react";
import * as CheckboxPrimitive from "@radix-ui/react-checkbox";
import * as RadioGroupPrimitive from "@radix-ui/react-radio-group";
import { Slot } from "@radix-ui/react-slot";
import * as PopoverPrimitive from "@radix-ui/react-popover";
import { DayPicker } from "react-day-picker";
import * as DialogPrimitive from "@radix-ui/react-dialog";
//#region src/components/layout/AppShell/AppShell.tsx
var FOCUSABLE_SELECTOR = [
	"a[href]",
	"button:not([disabled])",
	"input:not([disabled])",
	"select:not([disabled])",
	"textarea:not([disabled])",
	"[tabindex]:not([tabindex=\"-1\"])"
].join(", ");
function AppShell({ navigation, header, children, className = "", mobileNavigationOpen = false, onMobileNavigationOpenChange }) {
	const navigationId = useId();
	const mobilePanelRef = useRef(null);
	const previousFocusRef = useRef(null);
	const isMobileNavigationOpen = navigation != null && mobileNavigationOpen;
	useEffect(() => {
		if (!isMobileNavigationOpen) return;
		const previousOverflow = document.body.style.overflow;
		previousFocusRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
		document.body.style.overflow = "hidden";
		const panel = mobilePanelRef.current;
		(panel?.querySelector(FOCUSABLE_SELECTOR) ?? panel)?.focus();
		return () => {
			document.body.style.overflow = previousOverflow;
			previousFocusRef.current?.focus();
		};
	}, [isMobileNavigationOpen]);
	useEffect(() => {
		if (!isMobileNavigationOpen) return;
		const mediaQuery = window.matchMedia("(min-width: 64rem)");
		const handleViewportChange = (event) => {
			if (event.matches) onMobileNavigationOpenChange?.(false);
		};
		mediaQuery.addEventListener("change", handleViewportChange);
		return () => {
			mediaQuery.removeEventListener("change", handleViewportChange);
		};
	}, [isMobileNavigationOpen, onMobileNavigationOpenChange]);
	function handleMobileNavigationKeyDown(event) {
		if (event.key === "Escape") {
			event.preventDefault();
			onMobileNavigationOpenChange?.(false);
			return;
		}
		if (event.key !== "Tab") return;
		const panel = mobilePanelRef.current;
		if (!panel) return;
		const focusableElements = Array.from(panel.querySelectorAll(FOCUSABLE_SELECTOR)).filter((element) => element.getClientRects().length > 0);
		if (focusableElements.length === 0) {
			event.preventDefault();
			panel.focus();
			return;
		}
		const first = focusableElements[0];
		const last = focusableElements[focusableElements.length - 1];
		if (event.shiftKey && (document.activeElement === first || document.activeElement === panel)) {
			event.preventDefault();
			last.focus();
		} else if (!event.shiftKey && document.activeElement === last) {
			event.preventDefault();
			first.focus();
		}
	}
	return /* @__PURE__ */ jsxs("div", {
		className: `flex min-h-screen flex-col bg-background text-text-primary ${className}`,
		children: [
			header != null && /* @__PURE__ */ jsx("div", {
				className: "shrink-0",
				inert: isMobileNavigationOpen,
				children: header
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex min-h-0 flex-1",
				children: [navigation != null && /* @__PURE__ */ jsx("aside", {
					"aria-label": "Desktop navigation",
					className: "hidden shrink-0 lg:block",
					children: navigation
				}), /* @__PURE__ */ jsx("main", {
					className: "min-w-0 flex-1",
					inert: isMobileNavigationOpen,
					children
				})]
			}),
			navigation != null && /* @__PURE__ */ jsxs("div", {
				className: `fixed inset-0 z-50 lg:hidden ${isMobileNavigationOpen ? "" : "hidden"}`,
				"aria-hidden": isMobileNavigationOpen ? void 0 : true,
				children: [/* @__PURE__ */ jsx("button", {
					type: "button",
					"aria-label": "Close navigation",
					tabIndex: isMobileNavigationOpen ? 0 : -1,
					className: "absolute inset-0 bg-black/50",
					onClick: () => onMobileNavigationOpenChange?.(false)
				}), isMobileNavigationOpen && /* @__PURE__ */ jsxs("div", {
					id: navigationId,
					ref: mobilePanelRef,
					role: "dialog",
					"aria-modal": "true",
					"aria-label": "Mobile navigation",
					tabIndex: -1,
					onKeyDown: handleMobileNavigationKeyDown,
					className: "absolute inset-y-0 left-0 flex h-full max-w-[calc(100vw-3rem)] flex-col overflow-y-auto bg-surface shadow-lg",
					children: [/* @__PURE__ */ jsx("div", {
						className: "flex min-h-14 shrink-0 items-center justify-end border-b border-border px-3",
						children: /* @__PURE__ */ jsx("button", {
							type: "button",
							"aria-label": "Close navigation",
							onClick: () => onMobileNavigationOpenChange?.(false),
							className: "flex size-10 items-center justify-center rounded-sm hover:bg-background focus-visible:outline-2 focus-visible:outline-primary",
							children: /* @__PURE__ */ jsx("span", {
								"aria-hidden": "true",
								className: "text-xl",
								children: "×"
							})
						})
					}), /* @__PURE__ */ jsx("div", {
						className: "min-h-0 flex-1",
						children: navigation
					})]
				})]
			})
		]
	});
}
//#endregion
//#region src/components/layout/Sidebar/Sidebar.tsx
function Sidebar({ groups, activeItemId, collapsed = false, onCollapsedChange, header, footer, className = "" }) {
	const navigationId = useId();
	return /* @__PURE__ */ jsxs("div", {
		className: `flex h-full shrink-0 flex-col border-r border-border bg-surface text-text-primary ${collapsed ? "w-18" : "w-64"} ${className}`,
		children: [
			header != null && /* @__PURE__ */ jsx("div", {
				className: "shrink-0 overflow-hidden border-b border-border p-4",
				children: header
			}),
			onCollapsedChange && /* @__PURE__ */ jsxs("button", {
				type: "button",
				"aria-label": collapsed ? "Expand navigation" : "Collapse navigation",
				"aria-expanded": !collapsed,
				"aria-controls": navigationId,
				onClick: () => onCollapsedChange(!collapsed),
				className: "body-sm m-3 flex min-h-12 items-center justify-center gap-3 rounded-md hover:bg-background focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary",
				children: [/* @__PURE__ */ jsx("span", {
					"aria-hidden": "true",
					children: collapsed ? "»" : "«"
				}), !collapsed && /* @__PURE__ */ jsx("span", { children: "Collapse navigation" })]
			}),
			/* @__PURE__ */ jsx("nav", {
				id: navigationId,
				"aria-label": "Main navigation",
				className: "min-h-0 flex-1 space-y-6 overflow-y-auto p-3",
				children: groups.map((group, index) => {
					const labelId = `${navigationId}-group-${index}`;
					return /* @__PURE__ */ jsxs("div", {
						role: "group",
						"aria-labelledby": group.label ? labelId : void 0,
						children: [group.label && /* @__PURE__ */ jsx("div", {
							id: labelId,
							className: collapsed ? "sr-only" : "caption mb-2 px-3 text-text-secondary",
							children: group.label
						}), /* @__PURE__ */ jsx("ul", {
							className: "space-y-1",
							children: group.items.map((item) => {
								const active = item.id === activeItemId;
								const itemClassName = `body-sm flex min-h-12 w-full items-center rounded-md font-medium focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary ${collapsed ? "justify-center px-1" : "gap-3 px-3 text-left"} ${active ? "bg-primary text-primary-contrast" : "text-text-primary"} ${item.disabled ? "cursor-not-allowed opacity-50" : active ? "hover:bg-primary-hover" : "hover:bg-background"}`;
								const content = /* @__PURE__ */ jsxs(Fragment, { children: [
									item.icon != null && /* @__PURE__ */ jsx("span", {
										"aria-hidden": "true",
										className: "flex size-6 shrink-0 items-center justify-center",
										children: item.icon
									}),
									collapsed && item.icon == null && /* @__PURE__ */ jsx("span", {
										"aria-hidden": "true",
										children: item.label.slice(0, 1)
									}),
									/* @__PURE__ */ jsx("span", {
										className: collapsed ? "sr-only" : "min-w-0 break-words",
										children: item.label
									})
								] });
								return /* @__PURE__ */ jsx("li", { children: item.href !== void 0 ? /* @__PURE__ */ jsx("a", {
									href: item.disabled ? void 0 : item.href,
									role: item.disabled ? "link" : void 0,
									"aria-disabled": item.disabled || void 0,
									"aria-current": active ? "page" : void 0,
									tabIndex: item.disabled ? -1 : void 0,
									title: collapsed ? item.label : void 0,
									onClick: item.disabled ? (event) => event.preventDefault() : item.onClick,
									className: itemClassName,
									children: content
								}) : /* @__PURE__ */ jsx("button", {
									type: "button",
									disabled: item.disabled,
									"aria-current": active ? "page" : void 0,
									title: collapsed ? item.label : void 0,
									onClick: item.onClick,
									className: itemClassName,
									children: content
								}) }, item.id);
							})
						})]
					}, group.id);
				})
			}),
			footer != null && /* @__PURE__ */ jsx("div", {
				className: "shrink-0 overflow-hidden border-t border-border p-4",
				children: footer
			})
		]
	});
}
//#endregion
//#region src/components/layout/Header/Header.tsx
function Header({ logo, navigation, actions, className = "" }) {
	return /* @__PURE__ */ jsxs("header", {
		className: `flex min-h-16 flex-wrap items-center gap-4 bg-primary px-6 py-3 text-primary-contrast ${className}`,
		children: [
			/* @__PURE__ */ jsx("div", {
				className: "flex min-w-0 shrink-0 items-center",
				children: logo
			}),
			navigation != null && /* @__PURE__ */ jsx("div", {
				className: "order-3 flex w-full min-w-0 items-center justify-center lg:order-none lg:w-auto lg:flex-1",
				children: navigation
			}),
			actions != null && /* @__PURE__ */ jsx("div", {
				className: "ml-auto flex shrink-0 items-center gap-3",
				children: actions
			})
		]
	});
}
//#endregion
//#region src/components/layout/ContentLayout/ContentLayout.tsx
var widthClasses = {
	constrained: "max-w-5xl",
	wide: "max-w-7xl",
	fluid: "max-w-none"
};
function ContentLayout({ children, width = "constrained", className = "" }) {
	return /* @__PURE__ */ jsx("div", {
		className: "w-full min-w-0 px-4 py-6 sm:px-6 lg:px-8",
		children: /* @__PURE__ */ jsx("div", {
			className: `mx-auto w-full min-w-0 ${widthClasses[width]} ${className}`,
			children
		})
	});
}
//#endregion
//#region src/utilities/cn.ts
function cn(...classes) {
	return twMerge(classes.filter(Boolean).join(" "));
}
//#endregion
//#region src/components/actions/Button/Button.tsx
var sizeClasses$12 = {
	sm: "h-8 gap-1.5 px-3 text-body-sm",
	md: "h-10 gap-2 px-4 text-body-md",
	lg: "h-12 gap-2.5 px-5 text-body-lg"
};
var iconSizeClasses$2 = {
	sm: "size-8",
	md: "size-10",
	lg: "size-12"
};
var radiusClasses$6 = {
	sm: "rounded-sm",
	md: "rounded-md",
	lg: "rounded-lg",
	full: "rounded-full"
};
var spinnerSizeClasses = {
	sm: "size-3.5",
	md: "size-4",
	lg: "size-5"
};
var colorClasses$4 = {
	primary: {
		solid: "bg-primary text-primary-contrast hover:bg-primary-hover active:bg-primary-active",
		outline: "border border-primary text-primary hover:bg-primary-soft active:bg-primary-soft",
		ghost: "text-primary hover:bg-primary-soft active:bg-primary-soft",
		soft: "bg-primary-soft text-primary hover:bg-primary-soft/80 active:bg-primary-soft",
		white: "border border-border bg-surface text-primary hover:bg-primary-soft active:bg-primary-soft",
		link: "text-primary underline-offset-4 hover:underline active:opacity-75"
	},
	secondary: {
		solid: "bg-secondary text-secondary-contrast hover:bg-secondary-hover active:bg-secondary-active",
		outline: "border border-secondary text-secondary hover:bg-secondary-soft active:bg-secondary-soft",
		ghost: "text-secondary hover:bg-secondary-soft active:bg-secondary-soft",
		soft: "bg-secondary-soft text-secondary hover:bg-secondary-soft/80 active:bg-secondary-soft",
		white: "border border-border bg-surface text-secondary hover:bg-secondary-soft active:bg-secondary-soft",
		link: "text-secondary underline-offset-4 hover:underline active:opacity-75"
	},
	success: {
		solid: "bg-success text-success-contrast hover:bg-success-hover active:bg-success-active",
		outline: "border border-success text-success hover:bg-success-soft active:bg-success-soft",
		ghost: "text-success hover:bg-success-soft active:bg-success-soft",
		soft: "bg-success-soft text-success hover:bg-success-soft/80 active:bg-success-soft",
		white: "border border-border bg-surface text-success hover:bg-success-soft active:bg-success-soft",
		link: "text-success underline-offset-4 hover:underline active:opacity-75"
	},
	warning: {
		solid: "bg-warning text-warning-contrast hover:bg-warning-hover active:bg-warning-active",
		outline: "border border-warning text-warning hover:bg-warning-soft active:bg-warning-soft",
		ghost: "text-warning hover:bg-warning-soft active:bg-warning-soft",
		soft: "bg-warning-soft text-warning hover:bg-warning-soft/80 active:bg-warning-soft",
		white: "border border-border bg-surface text-warning hover:bg-warning-soft active:bg-warning-soft",
		link: "text-warning underline-offset-4 hover:underline active:opacity-75"
	},
	error: {
		solid: "bg-error text-error-contrast hover:bg-error-hover active:bg-error-active",
		outline: "border border-error text-error hover:bg-error-soft active:bg-error-soft",
		ghost: "text-error hover:bg-error-soft active:bg-error-soft",
		soft: "bg-error-soft text-error hover:bg-error-soft/80 active:bg-error-soft",
		white: "border border-border bg-surface text-error hover:bg-error-soft active:bg-error-soft",
		link: "text-error underline-offset-4 hover:underline active:opacity-75"
	},
	info: {
		solid: "bg-info text-info-contrast hover:bg-info-hover active:bg-info-active",
		outline: "border border-info text-info hover:bg-info-soft active:bg-info-soft",
		ghost: "text-info hover:bg-info-soft active:bg-info-soft",
		soft: "bg-info-soft text-info hover:bg-info-soft/80 active:bg-info-soft",
		white: "border border-border bg-surface text-info hover:bg-info-soft active:bg-info-soft",
		link: "text-info underline-offset-4 hover:underline active:opacity-75"
	},
	neutral: {
		solid: "bg-text-primary text-text-inverse hover:opacity-90 active:opacity-80",
		outline: "border border-border text-text-primary hover:bg-background active:bg-background",
		ghost: "text-text-primary hover:bg-background active:bg-background",
		soft: "bg-background text-text-primary hover:brightness-95 active:brightness-90",
		white: "border border-border bg-surface text-text-primary hover:bg-background active:bg-background",
		link: "text-text-primary underline-offset-4 hover:underline active:opacity-75"
	}
};
function LoadingSpinner({ size }) {
	return /* @__PURE__ */ jsxs("svg", {
		"aria-hidden": "true",
		viewBox: "0 0 24 24",
		fill: "none",
		className: `${spinnerSizeClasses[size]} shrink-0 animate-spin`,
		children: [/* @__PURE__ */ jsx("circle", {
			cx: "12",
			cy: "12",
			r: "9",
			stroke: "currentColor",
			strokeWidth: "3",
			opacity: "0.25"
		}), /* @__PURE__ */ jsx("path", {
			d: "M21 12a9 9 0 0 0-9-9",
			stroke: "currentColor",
			strokeWidth: "3",
			strokeLinecap: "round"
		})]
	});
}
function Button({ variant = "solid", color = "primary", size = "md", radius = "sm", fullWidth = false, loading = false, loadingText, startIcon, endIcon, iconOnly = false, disabled = false, type = "button", className = "", children, ...props }) {
	const isDisabled = disabled || loading;
	const classes = cn("relative inline-flex shrink-0 items-center justify-center", "font-medium whitespace-nowrap", "transition-colors duration-150", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary", "disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50", iconOnly ? iconSizeClasses$2[size] : sizeClasses$12[size], radiusClasses$6[radius], colorClasses$4[color][variant], fullWidth && "w-full", className);
	return /* @__PURE__ */ jsx("button", {
		...props,
		type,
		className: classes,
		disabled: isDisabled,
		"aria-busy": loading || void 0,
		children: loading ? /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(LoadingSpinner, { size }), !iconOnly && /* @__PURE__ */ jsx("span", { children: loadingText ?? children })] }) : /* @__PURE__ */ jsx(Fragment, { children: iconOnly ? /* @__PURE__ */ jsx("span", {
			className: "flex items-center justify-center",
			children: children ?? startIcon ?? endIcon
		}) : /* @__PURE__ */ jsxs(Fragment, { children: [
			startIcon != null && /* @__PURE__ */ jsx("span", {
				"aria-hidden": "true",
				className: "flex shrink-0 items-center",
				children: startIcon
			}),
			children,
			endIcon != null && /* @__PURE__ */ jsx("span", {
				"aria-hidden": "true",
				className: "flex shrink-0 items-center",
				children: endIcon
			})
		] }) })
	});
}
//#endregion
//#region src/components/surfaces/Card/Card.tsx
var variantClasses$3 = {
	outlined: "border border-border",
	elevated: "border border-border shadow-md",
	filled: "bg-background"
};
var Card = forwardRef(function Card({ variant = "outlined", className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("div", {
		ref,
		className: cn("flex flex-col overflow-hidden rounded-md bg-surface text-text-primary", variantClasses$3[variant], className),
		...props,
		children
	});
});
var CardHeader = forwardRef(function CardHeader({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("div", {
		ref,
		className: cn("flex flex-col gap-1 p-6", className),
		...props,
		children
	});
});
var CardTitle = forwardRef(function CardTitle({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("h3", {
		ref,
		className: cn("heading-sm text-text-primary", className),
		...props,
		children
	});
});
var CardDescription = forwardRef(function CardDescription({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("p", {
		ref,
		className: cn("body-sm text-text-secondary", className),
		...props,
		children
	});
});
var CardContent = forwardRef(function CardContent({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("div", {
		ref,
		className: cn("p-6", className),
		...props,
		children
	});
});
var CardFooter = forwardRef(function CardFooter({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("div", {
		ref,
		className: cn("flex items-center gap-3 p-6", className),
		...props,
		children
	});
});
var CardMedia = forwardRef(function CardMedia({ className, alt, ...props }, ref) {
	return /* @__PURE__ */ jsx("img", {
		ref,
		alt: alt ?? "",
		className: cn("block w-full object-cover", className),
		...props
	});
});
//#endregion
//#region src/components/data-display/Badge/Badge.tsx
var sizeClasses$11 = {
	sm: "gap-1 px-2 py-0.5 text-caption",
	md: "gap-1.5 px-2.5 py-1 text-body-sm",
	lg: "gap-2 px-3 py-1.5 text-body-md"
};
var radiusClasses$5 = {
	sm: "rounded-sm",
	md: "rounded-md",
	lg: "rounded-lg",
	full: "rounded-full"
};
var colorClasses$3 = {
	primary: {
		solid: "bg-primary text-primary-contrast",
		soft: "bg-primary-soft text-primary",
		outline: "border border-primary text-primary",
		white: "border border-border bg-surface text-primary"
	},
	secondary: {
		solid: "bg-secondary text-secondary-contrast",
		soft: "bg-secondary-soft text-secondary",
		outline: "border border-secondary text-secondary",
		white: "border border-border bg-surface text-secondary"
	},
	success: {
		solid: "bg-success text-success-contrast",
		soft: "bg-success-soft text-success",
		outline: "border border-success text-success",
		white: "border border-border bg-surface text-success"
	},
	warning: {
		solid: "bg-warning text-warning-contrast",
		soft: "bg-warning-soft text-warning",
		outline: "border border-warning text-warning",
		white: "border border-border bg-surface text-warning"
	},
	error: {
		solid: "bg-error text-error-contrast",
		soft: "bg-error-soft text-error",
		outline: "border border-error text-error",
		white: "border border-border bg-surface text-error"
	},
	info: {
		solid: "bg-info text-info-contrast",
		soft: "bg-info-soft text-info",
		outline: "border border-info text-info",
		white: "border border-border bg-surface text-info"
	},
	neutral: {
		solid: "bg-text-primary text-text-inverse",
		soft: "bg-background text-text-primary",
		outline: "border border-border text-text-primary",
		white: "border border-border bg-surface text-text-primary"
	}
};
var dotClasses = {
	primary: "bg-primary",
	secondary: "bg-secondary",
	success: "bg-success",
	warning: "bg-warning",
	error: "bg-error",
	info: "bg-info",
	neutral: "bg-text-primary"
};
var Badge = forwardRef(function Badge({ variant = "soft", color = "primary", size = "md", radius = "full", startIcon, endIcon, dot = false, truncate = false, className, children, ...props }, ref) {
	return /* @__PURE__ */ jsxs("span", {
		ref,
		className: cn("inline-flex max-w-full items-center align-middle font-medium", sizeClasses$11[size], radiusClasses$5[radius], colorClasses$3[color][variant], className),
		...props,
		children: [
			dot && /* @__PURE__ */ jsx("span", {
				"aria-hidden": "true",
				className: cn("size-1.5 shrink-0 rounded-full", variant === "solid" ? "bg-current" : dotClasses[color])
			}),
			startIcon != null && /* @__PURE__ */ jsx("span", {
				"aria-hidden": "true",
				className: "inline-flex shrink-0 items-center",
				children: startIcon
			}),
			/* @__PURE__ */ jsx("span", {
				className: cn("min-w-0", truncate && "truncate"),
				children
			}),
			endIcon != null && /* @__PURE__ */ jsx("span", {
				"aria-hidden": "true",
				className: "inline-flex shrink-0 items-center",
				children: endIcon
			})
		]
	});
});
//#endregion
//#region src/components/navigation/Tabs/Tabs.tsx
var TabsContext = createContext(null);
var TabsListContext = createContext(null);
function useTabsContext() {
	const context = useContext(TabsContext);
	if (!context) throw new Error("Tabs components must be used inside <Tabs>.");
	return context;
}
function useTabsListContext() {
	const context = useContext(TabsListContext);
	if (!context) throw new Error("TabsTrigger must be used inside <TabsList>.");
	return context;
}
function getTabId(baseId, value) {
	return `${baseId}-tab-${encodeURIComponent(value)}`;
}
function getPanelId(baseId, value) {
	return `${baseId}-panel-${encodeURIComponent(value)}`;
}
var Tabs = forwardRef(function Tabs({ value, defaultValue = "", onValueChange, orientation = "horizontal", className, children, ...props }, ref) {
	const baseId = useId();
	const [internalValue, setInternalValue] = useState(defaultValue);
	const isControlled = value !== void 0;
	const selectedValue = isControlled ? value : internalValue;
	const setValue = useCallback((nextValue) => {
		if (nextValue === selectedValue) return;
		if (!isControlled) setInternalValue(nextValue);
		onValueChange?.(nextValue);
	}, [
		isControlled,
		onValueChange,
		selectedValue
	]);
	return /* @__PURE__ */ jsx(TabsContext.Provider, {
		value: {
			value: selectedValue,
			setValue,
			orientation,
			baseId
		},
		children: /* @__PURE__ */ jsx("div", {
			...props,
			ref,
			"data-orientation": orientation,
			className: cn(orientation === "vertical" ? "flex items-start gap-4" : "flex flex-col gap-4", className),
			children
		})
	});
});
var alignClasses$1 = {
	start: "justify-start",
	center: "justify-center",
	end: "justify-end"
};
var listVariantClasses = {
	underline: "border-b border-border",
	pills: "",
	segment: "rounded-md bg-background p-1",
	card: "",
	bar: "rounded-sm border border-border"
};
var TabsList = forwardRef(function TabsList({ variant = "underline", size = "md", align = "start", fullWidth = false, scrollable = false, className, children, onKeyDown, ...props }, ref) {
	const { orientation, setValue } = useTabsContext();
	const internalRef = useRef(null);
	const isVertical = orientation === "vertical";
	const handleKeyDown = (event) => {
		onKeyDown?.(event);
		if (event.defaultPrevented) return;
		const key = event.key;
		const isNext = isVertical ? key === "ArrowDown" : key === "ArrowRight";
		const isPrevious = isVertical ? key === "ArrowUp" : key === "ArrowLeft";
		if (!isNext && !isPrevious && key !== "Home" && key !== "End") return;
		const triggers = Array.from(internalRef.current?.querySelectorAll("[role=\"tab\"]:not(:disabled)") ?? []);
		if (triggers.length === 0) return;
		const currentIndex = triggers.indexOf(document.activeElement);
		if (currentIndex === -1) return;
		event.preventDefault();
		let nextIndex = currentIndex;
		if (key === "Home") nextIndex = 0;
		else if (key === "End") nextIndex = triggers.length - 1;
		else if (isNext) nextIndex = (currentIndex + 1) % triggers.length;
		else if (isPrevious) nextIndex = (currentIndex - 1 + triggers.length) % triggers.length;
		const nextTrigger = triggers[nextIndex];
		if (!nextTrigger) return;
		nextTrigger.focus();
		if (!isVertical) {
			const list = internalRef.current;
			if (list && list.scrollWidth > list.clientWidth) {
				const triggerLeft = nextTrigger.offsetLeft;
				const triggerRight = triggerLeft + nextTrigger.offsetWidth;
				const visibleLeft = list.scrollLeft;
				const visibleRight = visibleLeft + list.clientWidth;
				if (triggerLeft < visibleLeft) list.scrollTo({
					left: triggerLeft,
					behavior: "smooth"
				});
				else if (triggerRight > visibleRight) list.scrollTo({
					left: triggerRight - list.clientWidth,
					behavior: "smooth"
				});
			}
		}
		const nextValue = nextTrigger.dataset.value;
		if (nextValue !== void 0) setValue(nextValue);
	};
	return /* @__PURE__ */ jsx(TabsListContext.Provider, {
		value: {
			variant,
			size,
			fullWidth
		},
		children: /* @__PURE__ */ jsx("div", {
			...props,
			ref: (node) => {
				internalRef.current = node;
				if (typeof ref === "function") ref(node);
				else if (ref) ref.current = node;
			},
			role: "tablist",
			"aria-orientation": orientation,
			onKeyDown: handleKeyDown,
			className: cn("flex min-w-0", isVertical ? "flex-col items-stretch" : "flex-row items-center", !isVertical && alignClasses$1[align], listVariantClasses[variant], isVertical && variant === "underline" && "border-b-0 border-r", scrollable && !isVertical && "max-w-full overflow-x-auto", fullWidth && "w-full", className),
			children
		})
	});
});
var triggerSizeClasses = {
	sm: "gap-1.5 px-3 py-1.5 text-body-sm",
	md: "gap-2 px-4 py-2 text-body-sm",
	lg: "gap-2 px-5 py-3 text-body-md"
};
var triggerVariantClasses = {
	underline: {
		base: "border-b-2 border-transparent",
		active: "border-primary text-primary",
		inactive: "text-text-secondary hover:text-text-primary"
	},
	pills: {
		base: "rounded-sm",
		active: "bg-primary text-primary-contrast",
		inactive: "text-text-secondary hover:bg-background"
	},
	segment: {
		base: "rounded-sm",
		active: "bg-surface text-primary shadow-sm",
		inactive: "text-text-secondary hover:text-text-primary"
	},
	card: {
		base: "rounded-sm border",
		active: "border-primary bg-primary-soft text-primary",
		inactive: "border-border bg-surface text-text-secondary hover:text-text-primary"
	},
	bar: {
		base: "border-b-2 border-transparent",
		active: "border-primary bg-primary-soft text-primary",
		inactive: "text-text-secondary hover:bg-background"
	}
};
var TabsTrigger = forwardRef(function TabsTrigger({ value, disabled = false, className, children, onClick, type, ...props }, ref) {
	const { value: selectedValue, setValue, orientation, baseId } = useTabsContext();
	const { variant, size, fullWidth } = useTabsListContext();
	const active = selectedValue === value;
	const styles = triggerVariantClasses[variant];
	return /* @__PURE__ */ jsx("button", {
		...props,
		ref,
		type: type ?? "button",
		role: "tab",
		id: getTabId(baseId, value),
		"aria-selected": active,
		"aria-controls": getPanelId(baseId, value),
		"data-value": value,
		"data-state": active ? "active" : "inactive",
		disabled,
		tabIndex: active ? 0 : -1,
		onClick: (event) => {
			onClick?.(event);
			if (!event.defaultPrevented && !disabled) setValue(value);
		},
		className: cn("inline-flex shrink-0 items-center justify-center whitespace-nowrap font-medium transition-colors", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary", "disabled:cursor-not-allowed disabled:opacity-50", triggerSizeClasses[size], styles.base, active ? styles.active : styles.inactive, fullWidth && "flex-1", orientation === "vertical" && variant === "underline" && "border-b-0 border-r-2", className),
		children
	});
});
var TabsContent = forwardRef(function TabsContent({ value, forceMount = false, className, children, ...props }, ref) {
	const { value: selectedValue, baseId } = useTabsContext();
	const active = selectedValue === value;
	return /* @__PURE__ */ jsx("div", {
		...props,
		ref,
		role: "tabpanel",
		id: getPanelId(baseId, value),
		"aria-labelledby": getTabId(baseId, value),
		"data-state": active ? "active" : "inactive",
		tabIndex: active ? 0 : -1,
		hidden: !active,
		className: cn("min-w-0 flex-1 outline-none", "focus-visible:ring-2 focus-visible:ring-primary", className),
		children: active || forceMount ? children : null
	});
});
//#endregion
//#region src/components/navigation/DropdownMenu/DropdownMenu.tsx
var DropdownMenu = DropdownMenuPrimitive.Root;
var DropdownMenuTrigger = DropdownMenuPrimitive.Trigger;
var DropdownMenuGroup = DropdownMenuPrimitive.Group;
var DropdownMenuContent = forwardRef(function DropdownMenuContent({ className, sideOffset = 6, align = "start", children, ...props }, ref) {
	return /* @__PURE__ */ jsx(DropdownMenuPrimitive.Portal, { children: /* @__PURE__ */ jsx(DropdownMenuPrimitive.Content, {
		ref,
		sideOffset,
		align,
		className: cn("z-50 min-w-44 overflow-hidden rounded-sm", "border border-border bg-surface p-1 shadow-lg", "text-text-primary", "data-[state=open]:animate-in", "data-[state=closed]:animate-out", "data-[side=bottom]:slide-in-from-top-1", "data-[side=top]:slide-in-from-bottom-1", "data-[side=left]:slide-in-from-right-1", "data-[side=right]:slide-in-from-left-1", className),
		...props,
		children
	}) });
});
var DropdownMenuItem = forwardRef(function DropdownMenuItem({ className, color = "default", ...props }, ref) {
	return /* @__PURE__ */ jsx(DropdownMenuPrimitive.Item, {
		ref,
		className: cn("relative flex cursor-default select-none items-center gap-2", "rounded-sm px-3 py-2 text-body-sm outline-none", "transition-colors", "focus:bg-primary-soft focus:text-primary", "data-[disabled]:pointer-events-none", "data-[disabled]:opacity-50", color === "error" && "text-error focus:bg-error-soft focus:text-error", className),
		...props
	});
});
var DropdownMenuLabel = forwardRef(function DropdownMenuLabel({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx(DropdownMenuPrimitive.Label, {
		ref,
		className: cn("px-3 py-2 text-body-sm font-semibold text-text-primary", className),
		...props
	});
});
var DropdownMenuSeparator = forwardRef(function DropdownMenuSeparator({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx(DropdownMenuPrimitive.Separator, {
		ref,
		className: cn("my-1 h-px bg-border", className),
		...props
	});
});
//#endregion
//#region src/components/data-display/Tooltip/Tooltip.tsx
var TooltipProvider = TooltipPrimitive.Provider;
var Tooltip = TooltipPrimitive.Root;
var TooltipTrigger = TooltipPrimitive.Trigger;
var variantClasses$2 = {
	default: "bg-text-primary text-text-inverse",
	light: "border border-border bg-surface text-text-primary shadow-md",
	primary: "bg-primary text-primary-contrast"
};
var arrowClasses = {
	default: "fill-text-primary",
	light: "fill-surface",
	primary: "fill-primary"
};
var TooltipContent = forwardRef(function TooltipContent({ variant = "default", arrow = false, side = "top", align = "center", sideOffset = 6, className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx(TooltipPrimitive.Portal, { children: /* @__PURE__ */ jsxs(TooltipPrimitive.Content, {
		...props,
		ref,
		side,
		align,
		sideOffset,
		className: cn("z-50 max-w-xs rounded-sm px-3 py-2", "text-body-sm leading-relaxed", "shadow-sm", "select-none", variantClasses$2[variant], className),
		children: [children, arrow && /* @__PURE__ */ jsx(TooltipPrimitive.Arrow, {
			"aria-hidden": "true",
			width: 10,
			height: 5,
			className: cn(arrowClasses[variant])
		})]
	}) });
});
//#endregion
//#region src/components/data-display/Avatar/Avatar.tsx
var sizeClasses$10 = {
	xs: "size-7",
	sm: "size-9",
	md: "size-11",
	lg: "size-14",
	xl: "size-[4.5rem]"
};
var radiusClasses$4 = {
	sm: "rounded-sm",
	md: "rounded-md",
	lg: "rounded-lg",
	full: "rounded-full"
};
var Avatar = forwardRef(function Avatar({ size = "md", radius = "full", className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx(AvatarPrimitive.Root, {
		...props,
		ref,
		"data-size": size,
		"data-radius": radius,
		className: cn("relative inline-flex shrink-0 items-center justify-center", "overflow-hidden bg-primary-soft", sizeClasses$10[size], radiusClasses$4[radius], className),
		children
	});
});
var AvatarImage = forwardRef(function AvatarImage({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx(AvatarPrimitive.Image, {
		...props,
		ref,
		className: cn("aspect-square size-full object-cover", className)
	});
});
var AvatarFallback = forwardRef(function AvatarFallback({ className, children, delayMs = 300, ...props }, ref) {
	return /* @__PURE__ */ jsx(AvatarPrimitive.Fallback, {
		...props,
		ref,
		delayMs,
		className: cn("flex size-full items-center justify-center", "bg-primary-soft text-primary", "font-semibold select-none", "text-body-sm", className),
		children
	});
});
//#endregion
//#region src/components/layout/Separator/Separator.tsx
var Separator = forwardRef(function Separator({ orientation = "horizontal", decorative = true, className, ...props }, ref) {
	return /* @__PURE__ */ jsx(SeparatorPrimitive.Root, {
		...props,
		ref,
		orientation,
		decorative,
		className: cn("shrink-0 bg-border", "data-[orientation=horizontal]:h-px", "data-[orientation=horizontal]:w-full", "data-[orientation=vertical]:h-full", "data-[orientation=vertical]:w-px", className)
	});
});
//#endregion
//#region src/components/forms/Input/Input.tsx
var sizeClasses$9 = {
	sm: "h-9 px-3 text-body-sm",
	md: "h-11 px-4 text-body-md",
	lg: "h-14 px-5 text-body-lg"
};
var radiusClasses$3 = {
	sm: "rounded-sm",
	md: "rounded-md",
	lg: "rounded-lg",
	full: "rounded-full"
};
var iconSizeClasses$1 = {
	sm: "[&_svg]:size-4",
	md: "[&_svg]:size-5",
	lg: "[&_svg]:size-5"
};
var Input = forwardRef(function Input({ size = "md", radius = "sm", type = "text", startIcon, endIcon, endAdornment, invalid = false, disabled, readOnly, className, "aria-invalid": ariaInvalid, ...props }, ref) {
	const isInvalid = invalid || ariaInvalid === true || ariaInvalid === "true";
	return /* @__PURE__ */ jsxs("div", {
		"data-disabled": disabled ? "true" : void 0,
		"data-readonly": readOnly ? "true" : void 0,
		"data-invalid": isInvalid ? "true" : void 0,
		className: cn("group relative flex w-full items-center", "border border-border bg-surface text-text-primary", "transition-colors duration-150", "hover:border-text-secondary", "focus-within:border-primary", "data-[invalid=true]:border-error", "data-[invalid=true]:focus-within:border-error", "data-[disabled=true]:cursor-not-allowed", "data-[disabled=true]:bg-background", "data-[disabled=true]:opacity-50", "data-[disabled=true]:hover:border-border", "data-[readonly=true]:bg-background", "data-[readonly=true]:hover:border-border", sizeClasses$9[size], radiusClasses$3[radius], iconSizeClasses$1[size], className),
		children: [
			startIcon && /* @__PURE__ */ jsx("span", {
				"aria-hidden": "true",
				className: cn("mr-3 flex shrink-0 items-center justify-center", "text-text-secondary"),
				children: startIcon
			}),
			/* @__PURE__ */ jsx("input", {
				...props,
				ref,
				type,
				disabled,
				readOnly,
				"aria-invalid": isInvalid ? true : ariaInvalid,
				className: cn("h-full min-w-0 flex-1 bg-transparent", "text-inherit outline-none", "placeholder:text-text-secondary", "disabled:cursor-not-allowed", "read-only:cursor-default")
			}),
			endIcon && /* @__PURE__ */ jsx("span", {
				"aria-hidden": "true",
				className: cn("ml-3 flex shrink-0 items-center justify-center", "text-text-secondary"),
				children: endIcon
			}),
			endAdornment && /* @__PURE__ */ jsx("span", {
				className: "ml-3 flex shrink-0 items-center justify-center",
				children: endAdornment
			})
		]
	});
});
//#endregion
//#region src/components/forms/Textarea/Textarea.tsx
var sizeClasses$8 = {
	sm: "px-3 py-2 text-body-sm",
	md: "px-4 py-3 text-body-md",
	lg: "px-5 py-4 text-body-lg"
};
var radiusClasses$2 = {
	sm: "rounded-sm",
	md: "rounded-md",
	lg: "rounded-lg"
};
var resizeClasses = {
	none: "resize-none",
	vertical: "resize-y",
	horizontal: "resize-x",
	both: "resize"
};
var Textarea = forwardRef(function Textarea({ size = "md", radius = "sm", resize = "vertical", rows = 4, invalid = false, disabled, readOnly, className, "aria-invalid": ariaInvalid, ...props }, ref) {
	const isInvalid = invalid || ariaInvalid === true || ariaInvalid === "true";
	return /* @__PURE__ */ jsx("textarea", {
		...props,
		ref,
		rows,
		disabled,
		readOnly,
		"aria-invalid": isInvalid ? true : ariaInvalid,
		"data-invalid": isInvalid ? "true" : void 0,
		className: cn("block w-full min-w-0", "border border-border bg-surface text-text-primary", "placeholder:text-text-secondary", "transition-colors duration-150", "hover:border-text-secondary", "focus:border-primary focus:outline-none", "data-[invalid=true]:border-error", "data-[invalid=true]:focus:border-error", "disabled:cursor-not-allowed", "disabled:bg-background", "disabled:opacity-50", "disabled:hover:border-border", "read-only:cursor-default", "read-only:bg-background", "read-only:hover:border-border", sizeClasses$8[size], radiusClasses$2[radius], resizeClasses[resize], className)
	});
});
//#endregion
//#region src/components/forms/Select/Select.tsx
var sizeClasses$7 = {
	sm: "h-9 px-3 text-body-sm",
	md: "h-11 px-4 text-body-md",
	lg: "h-14 px-5 text-body-lg"
};
var radiusClasses$1 = {
	sm: "rounded-sm",
	md: "rounded-md",
	lg: "rounded-lg",
	full: "rounded-full"
};
var Select = SelectPrimitive.Root;
var SelectTrigger = forwardRef(function SelectTrigger({ size = "md", radius = "sm", invalid = false, className, children, "aria-invalid": ariaInvalid, ...props }, ref) {
	const isInvalid = invalid || ariaInvalid === true || ariaInvalid === "true";
	return /* @__PURE__ */ jsxs(SelectPrimitive.Trigger, {
		...props,
		ref,
		"aria-invalid": isInvalid ? true : ariaInvalid,
		"data-invalid": isInvalid ? "true" : void 0,
		className: cn("flex w-full items-center justify-between gap-3", "border border-border bg-surface text-text-primary", "transition-colors duration-150", "hover:border-text-secondary", "focus:border-primary focus:outline-none", "data-[state=open]:border-primary", "data-[invalid=true]:border-error", "data-[invalid=true]:focus:border-error", "data-[invalid=true]:data-[state=open]:border-error", "disabled:cursor-not-allowed", "disabled:bg-background", "disabled:opacity-50", "disabled:hover:border-border", "data-[placeholder]:text-text-secondary", sizeClasses$7[size], radiusClasses$1[radius], className),
		children: [/* @__PURE__ */ jsx("span", {
			className: "min-w-0 flex-1 truncate text-left",
			children
		}), /* @__PURE__ */ jsx(SelectPrimitive.Icon, {
			asChild: true,
			children: /* @__PURE__ */ jsx(ChevronDown, {
				size: 18,
				"aria-hidden": "true",
				className: "shrink-0 text-text-secondary"
			})
		})]
	});
});
var SelectValue = SelectPrimitive.Value;
var SelectContent = forwardRef(function SelectContent({ className, children, position = "popper", sideOffset = 4, ...props }, ref) {
	return /* @__PURE__ */ jsx(SelectPrimitive.Portal, { children: /* @__PURE__ */ jsxs(SelectPrimitive.Content, {
		...props,
		ref,
		position,
		sideOffset,
		className: cn("relative z-50 max-h-72 min-w-40 overflow-hidden", "rounded-sm border border-border", "bg-surface text-text-primary shadow-md", "data-[state=closed]:pointer-events-none", className),
		children: [
			/* @__PURE__ */ jsx(SelectScrollUpButton, {}),
			/* @__PURE__ */ jsx(SelectPrimitive.Viewport, {
				className: cn("p-1", position === "popper" && "w-full min-w-[var(--radix-select-trigger-width)]"),
				children
			}),
			/* @__PURE__ */ jsx(SelectScrollDownButton, {})
		]
	}) });
});
var SelectItem = forwardRef(function SelectItem({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsxs(SelectPrimitive.Item, {
		...props,
		ref,
		className: cn("relative flex w-full cursor-default items-center", "rounded-sm py-2 pr-8 pl-3", "text-body-sm text-text-primary", "outline-none select-none", "focus:bg-primary-soft focus:text-primary", "data-[state=checked]:font-medium", "data-[disabled]:pointer-events-none", "data-[disabled]:opacity-40", className),
		children: [/* @__PURE__ */ jsx(SelectPrimitive.ItemText, { children }), /* @__PURE__ */ jsx("span", {
			className: "absolute right-2 flex size-4 items-center justify-center",
			children: /* @__PURE__ */ jsx(SelectPrimitive.ItemIndicator, { children: /* @__PURE__ */ jsx(Check, {
				size: 16,
				"aria-hidden": "true",
				className: "text-primary"
			}) })
		})]
	});
});
var SelectGroup = SelectPrimitive.Group;
var SelectLabel = forwardRef(function SelectLabel({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx(SelectPrimitive.Label, {
		...props,
		ref,
		className: cn("px-3 py-2", "text-body-sm font-semibold text-text-secondary", className)
	});
});
var SelectSeparator = forwardRef(function SelectSeparator({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx(SelectPrimitive.Separator, {
		...props,
		ref,
		className: cn("my-1 h-px bg-border", className)
	});
});
var SelectScrollUpButton = forwardRef(function SelectScrollUpButton({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx(SelectPrimitive.ScrollUpButton, {
		...props,
		ref,
		className: cn("flex h-7 cursor-default items-center justify-center", "bg-surface text-text-secondary", className),
		children: /* @__PURE__ */ jsx(ChevronUp, {
			size: 16,
			"aria-hidden": "true"
		})
	});
});
var SelectScrollDownButton = forwardRef(function SelectScrollDownButton({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx(SelectPrimitive.ScrollDownButton, {
		...props,
		ref,
		className: cn("flex h-7 cursor-default items-center justify-center", "bg-surface text-text-secondary", className),
		children: /* @__PURE__ */ jsx(ChevronDown, {
			size: 16,
			"aria-hidden": "true"
		})
	});
});
//#endregion
//#region src/components/forms/Checkbox/Checkbox.tsx
var sizeClasses$6 = {
	sm: "size-4",
	md: "size-5",
	lg: "size-6"
};
var iconSizeClasses = {
	sm: "[&_svg]:size-3",
	md: "[&_svg]:size-3.5",
	lg: "[&_svg]:size-4"
};
var colorClasses$2 = {
	primary: cn("data-[state=checked]:border-primary", "data-[state=checked]:bg-primary", "data-[state=indeterminate]:border-primary", "data-[state=indeterminate]:bg-primary", "focus-visible:border-primary"),
	secondary: cn("data-[state=checked]:border-secondary", "data-[state=checked]:bg-secondary", "data-[state=indeterminate]:border-secondary", "data-[state=indeterminate]:bg-secondary", "focus-visible:border-secondary"),
	success: cn("data-[state=checked]:border-success", "data-[state=checked]:bg-success", "data-[state=indeterminate]:border-success", "data-[state=indeterminate]:bg-success", "focus-visible:border-success"),
	warning: cn("data-[state=checked]:border-warning", "data-[state=checked]:bg-warning", "data-[state=indeterminate]:border-warning", "data-[state=indeterminate]:bg-warning", "focus-visible:border-warning"),
	error: cn("data-[state=checked]:border-error", "data-[state=checked]:bg-error", "data-[state=indeterminate]:border-error", "data-[state=indeterminate]:bg-error", "focus-visible:border-error"),
	info: cn("data-[state=checked]:border-info", "data-[state=checked]:bg-info", "data-[state=indeterminate]:border-info", "data-[state=indeterminate]:bg-info", "focus-visible:border-info")
};
var contrastClasses = {
	primary: "text-primary-contrast",
	secondary: "text-secondary-contrast",
	success: "text-success-contrast",
	warning: "text-warning-contrast",
	error: "text-error-contrast",
	info: "text-info-contrast"
};
var Checkbox = forwardRef(function Checkbox({ size = "md", color = "primary", className, ...props }, ref) {
	return /* @__PURE__ */ jsx(CheckboxPrimitive.Root, {
		...props,
		ref,
		className: cn("peer inline-flex shrink-0 items-center justify-center", "rounded-sm border border-border bg-surface", "transition-colors duration-150", "hover:border-text-secondary", "focus-visible:outline-none", "data-[state=checked]:hover:opacity-90", "data-[state=indeterminate]:hover:opacity-90", "disabled:cursor-not-allowed", "disabled:opacity-40", "disabled:hover:border-border", sizeClasses$6[size], colorClasses$2[color], className),
		children: /* @__PURE__ */ jsxs(CheckboxPrimitive.Indicator, {
			className: cn("flex size-full items-center justify-center", contrastClasses[color], iconSizeClasses[size]),
			children: [/* @__PURE__ */ jsx(Check, {
				"aria-hidden": "true",
				strokeWidth: 3,
				className: "hidden [[data-state=checked]>&]:block"
			}), /* @__PURE__ */ jsx(Minus, {
				"aria-hidden": "true",
				strokeWidth: 3,
				className: "hidden [[data-state=indeterminate]>&]:block"
			})]
		})
	});
});
//#endregion
//#region src/components/forms/RadioGroup/RadioGroup.tsx
var sizeClasses$5 = {
	sm: "size-4",
	md: "size-5",
	lg: "size-6"
};
var indicatorSizeClasses = {
	sm: "size-2",
	md: "size-2.5",
	lg: "size-3"
};
var colorClasses$1 = {
	primary: cn("data-[state=checked]:border-primary", "focus-visible:border-primary", "text-primary"),
	secondary: cn("data-[state=checked]:border-secondary", "focus-visible:border-secondary", "text-secondary"),
	success: cn("data-[state=checked]:border-success", "focus-visible:border-success", "text-success"),
	warning: cn("data-[state=checked]:border-warning", "focus-visible:border-warning", "text-warning"),
	error: cn("data-[state=checked]:border-error", "focus-visible:border-error", "text-error"),
	info: cn("data-[state=checked]:border-info", "focus-visible:border-info", "text-info")
};
var RadioGroup = forwardRef(function RadioGroup({ orientation = "vertical", className, ...props }, ref) {
	return /* @__PURE__ */ jsx(RadioGroupPrimitive.Root, {
		...props,
		ref,
		orientation,
		className: cn("flex", orientation === "horizontal" ? "flex-row flex-wrap items-center gap-6" : "flex-col gap-3", className)
	});
});
var RadioGroupItem = forwardRef(function RadioGroupItem({ size = "md", color = "primary", className, ...props }, ref) {
	return /* @__PURE__ */ jsx(RadioGroupPrimitive.Item, {
		...props,
		ref,
		className: cn("relative inline-flex shrink-0 items-center justify-center", "rounded-full border border-border bg-surface", "transition-colors duration-150", "hover:border-text-secondary", "focus-visible:outline-none", "disabled:cursor-not-allowed", "disabled:opacity-40", "disabled:hover:border-border", sizeClasses$5[size], colorClasses$1[color], className),
		children: /* @__PURE__ */ jsx(RadioGroupPrimitive.Indicator, {
			className: "flex items-center justify-center",
			children: /* @__PURE__ */ jsx("span", { className: cn("rounded-full bg-current", indicatorSizeClasses[size]) })
		})
	});
});
//#endregion
//#region src/components/forms/FormField/FormField.tsx
var FormFieldContext = createContext(null);
function useFormFieldContext() {
	const context = useContext(FormFieldContext);
	if (!context) throw new Error("FormField components must be used within FormField.");
	return context;
}
var FormField = forwardRef(function FormField({ invalid = false, required = false, className, children, ...props }, ref) {
	const id = useId();
	const contextValue = {
		controlId: `${id}-control`,
		descriptionId: `${id}-description`,
		errorId: `${id}-error`,
		invalid,
		required,
		hasDescription: true,
		hasError: invalid
	};
	return /* @__PURE__ */ jsx(FormFieldContext.Provider, {
		value: contextValue,
		children: /* @__PURE__ */ jsx("div", {
			...props,
			ref,
			"data-invalid": invalid || void 0,
			"data-required": required || void 0,
			className: cn("flex w-full flex-col gap-2", className),
			children
		})
	});
});
var FormFieldLabel = forwardRef(function FormFieldLabel({ className, children, htmlFor, ...props }, ref) {
	const { controlId, required } = useFormFieldContext();
	return /* @__PURE__ */ jsxs("label", {
		...props,
		ref,
		htmlFor: htmlFor ?? controlId,
		className: cn("inline-flex items-center gap-1.5", "body-sm font-medium text-text-primary", "cursor-pointer", className),
		children: [children, required && /* @__PURE__ */ jsx("span", {
			"aria-hidden": "true",
			className: "text-error",
			children: "*"
		})]
	});
});
var FormFieldControl = forwardRef(function FormFieldControl({ children, ...props }, ref) {
	const { controlId, descriptionId, errorId, invalid, required, hasDescription, hasError } = useFormFieldContext();
	const describedBy = [hasDescription ? descriptionId : null, hasError ? errorId : null].filter(Boolean).join(" ");
	return /* @__PURE__ */ jsx(Slot, {
		...props,
		ref,
		id: controlId,
		"aria-invalid": invalid || void 0,
		"aria-describedby": describedBy || void 0,
		"aria-required": required || void 0,
		required,
		children
	});
});
var FormFieldDescription = forwardRef(function FormFieldDescription({ className, children, ...props }, ref) {
	const { descriptionId } = useFormFieldContext();
	return /* @__PURE__ */ jsx("p", {
		...props,
		ref,
		id: descriptionId,
		className: cn("body-sm text-text-secondary", className),
		children
	});
});
var FormFieldError = forwardRef(function FormFieldError({ className, children, ...props }, ref) {
	const { errorId, invalid } = useFormFieldContext();
	if (!invalid || !children) return null;
	return /* @__PURE__ */ jsx("p", {
		...props,
		ref,
		id: errorId,
		className: cn("body-sm text-error", className),
		children
	});
});
//#endregion
//#region src/components/forms/MoneyInput/MoneyInput.tsx
var sizeClasses$4 = {
	sm: "h-9 px-3 text-body-sm",
	md: "h-11 px-4 text-body-md",
	lg: "h-13 px-4 text-body-lg"
};
function getCurrencyDigits(locale, currency) {
	return new Intl.NumberFormat(locale, {
		style: "currency",
		currency
	}).resolvedOptions().maximumFractionDigits ?? 2;
}
function fromMinorUnits(value, digits) {
	return value / 10 ** digits;
}
function formatMoney(value, locale, currency) {
	if (value === null) return "";
	return new Intl.NumberFormat(locale, {
		style: "currency",
		currency
	}).format(value);
}
function parseDigits(value) {
	return value.replace(/\D/g, "");
}
var MoneyInput = forwardRef(function MoneyInput({ value, defaultValue = null, onValueChange, currency = "BRL", locale = "pt-BR", allowNegative = false, invalid = false, size = "md", disabled, readOnly, className, onKeyDown, onChange, onFocus, onBlur, ...props }, ref) {
	const isControlled = value !== void 0;
	const [internalValue, setInternalValue] = useState(defaultValue);
	const currentValue = isControlled ? value : internalValue;
	const digits = getCurrencyDigits(locale, currency);
	const formattedValue = formatMoney(currentValue ?? null, locale, currency);
	function updateValue(nextValue) {
		if (!isControlled) setInternalValue(nextValue);
		onValueChange?.(nextValue);
	}
	function handleChange(event) {
		if (disabled || readOnly) return;
		const rawValue = event.target.value;
		const numericDigits = parseDigits(rawValue);
		if (!numericDigits) {
			updateValue(null);
			onChange?.(event);
			return;
		}
		const minorUnits = Number(numericDigits);
		if (!Number.isSafeInteger(minorUnits)) return;
		const nextValue = fromMinorUnits(minorUnits, digits);
		updateValue(allowNegative && (rawValue.includes("-") || currentValue !== null && currentValue !== void 0 && currentValue < 0) ? -nextValue : nextValue);
		onChange?.(event);
	}
	function handleKeyDown(event) {
		if (disabled || readOnly) {
			onKeyDown?.(event);
			return;
		}
		if (allowNegative && event.key === "-") {
			event.preventDefault();
			updateValue(currentValue === null ? 0 : -currentValue);
		}
		onKeyDown?.(event);
	}
	function handleFocus(event) {
		onFocus?.(event);
	}
	function handleBlur(event) {
		onBlur?.(event);
	}
	return /* @__PURE__ */ jsx("input", {
		...props,
		ref,
		type: "text",
		inputMode: "numeric",
		autoComplete: "off",
		disabled,
		readOnly,
		value: formattedValue,
		"aria-invalid": invalid || void 0,
		"data-invalid": invalid || void 0,
		onChange: handleChange,
		onKeyDown: handleKeyDown,
		onFocus: handleFocus,
		onBlur: handleBlur,
		className: cn("w-full min-w-0", "rounded-sm border border-border", "bg-surface text-text-primary", "font-body tabular-nums", "transition-colors duration-150", "placeholder:text-text-secondary", "hover:border-text-secondary", "focus:border-primary", "focus:outline-none", "data-[invalid=true]:border-error", "data-[invalid=true]:focus:border-error", "disabled:cursor-not-allowed", "disabled:opacity-50", "read-only:cursor-default", sizeClasses$4[size], className)
	});
});
//#endregion
//#region src/components/forms/DateInput/DateInput.tsx
var sizeClasses$3 = {
	sm: "h-9 px-3 text-body-sm",
	md: "h-11 px-4 text-body-md",
	lg: "h-13 px-4 text-body-lg"
};
function parseISO(value) {
	if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return;
	const [year, month, day] = value.split("-").map(Number);
	const date = new Date(year, month - 1, day);
	if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) return;
	return date;
}
function toISO(date) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function formatDate$1(value, format) {
	const date = parseISO(value);
	if (!date) return "";
	const year = String(date.getFullYear());
	const month = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");
	switch (format) {
		case "MM/dd/yyyy": return `${month}/${day}/${year}`;
		case "yyyy-MM-dd": return `${year}-${month}-${day}`;
		default: return `${day}/${month}/${year}`;
	}
}
function parseDate$1(value, format) {
	const parts = value.split(/[/-]/);
	if (parts.length !== 3) return null;
	let year;
	let month;
	let day;
	if (format === "dd/MM/yyyy") [day, month, year] = parts.map(Number);
	else if (format === "MM/dd/yyyy") [month, day, year] = parts.map(Number);
	else [year, month, day] = parts.map(Number);
	if (!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day) || year < 100 || year > 9999) return null;
	const iso = [
		String(year).padStart(4, "0"),
		String(month).padStart(2, "0"),
		String(day).padStart(2, "0")
	].join("-");
	return parseISO(iso) ? iso : null;
}
function isWithinRange(value, minDate, maxDate) {
	if (minDate && value < minDate) return false;
	if (maxDate && value > maxDate) return false;
	return true;
}
var DateInput = forwardRef(function DateInput({ value, defaultValue = null, onValueChange, format = "dd/MM/yyyy", minDate, maxDate, invalid = false, size = "md", disabled = false, readOnly = false, placeholder, className, id, onBlur, onKeyDown, ...props }, ref) {
	const isControlled = value !== void 0;
	const [internalValue, setInternalValue] = useState(defaultValue);
	const currentValue = isControlled ? value : internalValue;
	const [text, setText] = useState(formatDate$1(currentValue, format));
	const [open, setOpen] = useState(false);
	const [editingInvalid, setEditingInvalid] = useState(false);
	const selectedDate = parseISO(currentValue);
	const min = parseISO(minDate);
	const max = parseISO(maxDate);
	const [month, setMonth] = useState(selectedDate ?? /* @__PURE__ */ new Date());
	useEffect(() => {
		setText(formatDate$1(currentValue, format));
	}, [currentValue, format]);
	useEffect(() => {
		if (selectedDate) setMonth(selectedDate);
	}, [currentValue]);
	function updateValue(nextValue) {
		if (!isControlled) setInternalValue(nextValue);
		onValueChange?.(nextValue);
	}
	function commitText(rawText) {
		const trimmed = rawText.trim();
		if (!trimmed) {
			updateValue(null);
			setText("");
			setEditingInvalid(false);
			return;
		}
		const parsed = parseDate$1(trimmed, format);
		if (!parsed || !isWithinRange(parsed, minDate, maxDate)) {
			setEditingInvalid(true);
			return;
		}
		updateValue(parsed);
		setText(formatDate$1(parsed, format));
		setEditingInvalid(false);
	}
	function handleChange(event) {
		const nextText = event.target.value;
		setText(nextText);
		setEditingInvalid(false);
		if (!nextText.trim()) updateValue(null);
	}
	function handleKeyDown(event) {
		if (event.key === "Enter") commitText(text);
		if (event.key === "ArrowDown" && !readOnly && !disabled) {
			event.preventDefault();
			setOpen(true);
		}
		onKeyDown?.(event);
	}
	function handleSelect(date) {
		if (!date) return;
		const nextValue = toISO(date);
		if (!isWithinRange(nextValue, minDate, maxDate)) return;
		updateValue(nextValue);
		setText(formatDate$1(nextValue, format));
		setEditingInvalid(false);
		setOpen(false);
	}
	const isInvalid = invalid || editingInvalid;
	return /* @__PURE__ */ jsxs(PopoverPrimitive.Root, {
		open,
		onOpenChange: (nextOpen) => {
			if (!disabled && !readOnly) setOpen(nextOpen);
		},
		children: [/* @__PURE__ */ jsxs("div", {
			className: cn("flex w-full min-w-0 items-center", "rounded-sm border border-border bg-surface", "transition-colors duration-150", "hover:border-text-secondary", "focus-within:border-primary", "data-[invalid=true]:border-error", "data-[invalid=true]:focus-within:border-error", "data-[disabled=true]:cursor-not-allowed", "data-[disabled=true]:opacity-50", className),
			"data-invalid": isInvalid || void 0,
			"data-disabled": disabled || void 0,
			children: [/* @__PURE__ */ jsx("input", {
				...props,
				ref,
				id,
				type: "text",
				inputMode: "numeric",
				autoComplete: "off",
				value: text,
				disabled,
				readOnly,
				placeholder: placeholder ?? (format === "yyyy-MM-dd" ? "yyyy-mm-dd" : format),
				"aria-invalid": isInvalid || void 0,
				onChange: handleChange,
				onBlur: (event) => {
					commitText(text);
					onBlur?.(event);
				},
				onKeyDown: handleKeyDown,
				className: cn("min-w-0 flex-1 bg-transparent", "text-text-primary placeholder:text-text-secondary", "font-body tabular-nums", "outline-none", sizeClasses$3[size])
			}), /* @__PURE__ */ jsx(PopoverPrimitive.Trigger, {
				asChild: true,
				children: /* @__PURE__ */ jsx("button", {
					type: "button",
					disabled: disabled || readOnly,
					"aria-label": "Abrir calendário",
					className: cn("flex shrink-0 items-center justify-center", "text-text-secondary hover:text-primary", "disabled:cursor-not-allowed", "disabled:opacity-50", "focus-visible:outline-none", size === "sm" ? "h-9 w-9" : "", size === "md" ? "h-11 w-11" : "", size === "lg" ? "h-13 w-13" : ""),
					children: /* @__PURE__ */ jsx(CalendarDays, {
						"aria-hidden": "true",
						className: "size-4"
					})
				})
			})]
		}), /* @__PURE__ */ jsx(PopoverPrimitive.Portal, { children: /* @__PURE__ */ jsx(PopoverPrimitive.Content, {
			side: "bottom",
			align: "start",
			sideOffset: 6,
			className: cn("z-50 rounded-md border border-border", "bg-surface p-4 shadow-lg", "outline-none"),
			children: /* @__PURE__ */ jsx(DayPicker, {
				mode: "single",
				locale: void 0,
				selected: selectedDate,
				onSelect: handleSelect,
				month,
				onMonthChange: setMonth,
				disabled: [...min ? [{ before: min }] : [], ...max ? [{ after: max }] : []],
				startMonth: min,
				endMonth: max,
				showOutsideDays: true,
				components: { Chevron: ({ orientation }) => orientation === "left" ? /* @__PURE__ */ jsx(ChevronLeft, { className: "size-4" }) : /* @__PURE__ */ jsx(ChevronRight, { className: "size-4" }) },
				classNames: {
					root: "font-body text-text-primary",
					months: "flex flex-col",
					month: "space-y-3",
					month_caption: "flex items-center justify-center h-9",
					caption_label: "body-sm font-semibold text-text-primary",
					nav: "flex items-center gap-1",
					button_previous: "absolute left-4 top-4 flex size-8 items-center justify-center rounded-sm hover:bg-background",
					button_next: "absolute right-4 top-4 flex size-8 items-center justify-center rounded-sm hover:bg-background",
					month_grid: "w-full border-collapse",
					weekdays: "flex",
					weekday: "flex size-9 items-center justify-center body-sm text-text-secondary",
					week: "flex",
					day: "size-9 text-center",
					day_button: "flex size-9 items-center justify-center rounded-sm body-sm hover:bg-background",
					selected: "[&>button]:bg-primary [&>button]:text-primary-contrast [&>button]:hover:bg-primary-hover",
					today: "[&>button]:font-semibold",
					outside: "text-text-secondary opacity-40",
					disabled: "opacity-30 pointer-events-none",
					hidden: "invisible"
				}
			})
		}) })]
	});
});
//#endregion
//#region src/components/feedback/Alert/Alert.tsx
var AlertContext = createContext(null);
function useAlertContext() {
	const context = useContext(AlertContext);
	if (!context) throw new Error("Alert composition components must be used inside Alert.");
	return context;
}
var variantClasses$1 = {
	info: "border-info bg-info-soft text-info",
	success: "border-success bg-success-soft text-success",
	warning: "border-warning bg-warning-soft text-warning",
	danger: "border-error bg-error-soft text-error"
};
var defaultIcons$1 = {
	info: Info,
	success: CheckCircle2,
	warning: TriangleAlert,
	danger: CircleAlert
};
var Alert = forwardRef(function Alert({ variant = "info", dismissible = false, onDismiss, className, children, role, ...props }, ref) {
	const resolvedRole = role ?? (variant === "danger" ? "alert" : "status");
	return /* @__PURE__ */ jsx(AlertContext.Provider, {
		value: { variant },
		children: /* @__PURE__ */ jsxs("div", {
			...props,
			ref,
			role: resolvedRole,
			className: cn("relative flex w-full items-start gap-3", "rounded-md border p-4", variantClasses$1[variant], dismissible && "pr-12", className),
			children: [children, dismissible && /* @__PURE__ */ jsx("button", {
				type: "button",
				"aria-label": "Fechar alerta",
				onClick: onDismiss,
				className: cn("absolute right-3 top-3", "inline-flex size-7 items-center justify-center", "rounded-sm text-current opacity-70", "transition-opacity hover:opacity-100", "focus-visible:outline-2", "focus-visible:outline-offset-2", "focus-visible:outline-current", "cursor-pointer"),
				children: /* @__PURE__ */ jsx(X, {
					size: 16,
					"aria-hidden": "true"
				})
			})]
		})
	});
});
var AlertIcon = forwardRef(function AlertIcon({ className, children, ...props }, ref) {
	const { variant } = useAlertContext();
	const DefaultIcon = defaultIcons$1[variant];
	return /* @__PURE__ */ jsx("span", {
		...props,
		ref,
		"aria-hidden": "true",
		className: cn("mt-0.5 inline-flex shrink-0 items-center", className),
		children: children ?? /* @__PURE__ */ jsx(DefaultIcon, { size: 20 })
	});
});
var AlertContent = forwardRef(function AlertContent({ className, children, ...props }, ref) {
	useAlertContext();
	return /* @__PURE__ */ jsx("div", {
		...props,
		ref,
		className: cn("flex min-w-0 flex-1 flex-col gap-1", className),
		children
	});
});
var AlertTitle = forwardRef(function AlertTitle({ className, children, ...props }, ref) {
	useAlertContext();
	return /* @__PURE__ */ jsx("h3", {
		...props,
		ref,
		className: cn("text-body-md font-semibold leading-snug", className),
		children
	});
});
var AlertDescription = forwardRef(function AlertDescription({ className, children, ...props }, ref) {
	useAlertContext();
	return /* @__PURE__ */ jsx("p", {
		...props,
		ref,
		className: cn("text-body-sm leading-relaxed text-text-primary", className),
		children
	});
});
var AlertActions = forwardRef(function AlertActions({ className, children, ...props }, ref) {
	useAlertContext();
	return /* @__PURE__ */ jsx("div", {
		...props,
		ref,
		className: cn("mt-3 flex flex-wrap items-center gap-2", className),
		children
	});
});
//#endregion
//#region src/components/feedback/Toast/Toast.tsx
var appearanceClasses = {
	info: {
		default: "border-border bg-surface text-text-primary",
		soft: "border-info/20 bg-info-soft text-info",
		solid: "border-info bg-info text-info-contrast"
	},
	success: {
		default: "border-border bg-surface text-text-primary",
		soft: "border-success/20 bg-success-soft text-success",
		solid: "border-success bg-success text-success-contrast"
	},
	warning: {
		default: "border-border bg-surface text-text-primary",
		soft: "border-warning/20 bg-warning-soft text-warning",
		solid: "border-warning bg-warning text-warning-contrast"
	},
	danger: {
		default: "border-border bg-surface text-text-primary",
		soft: "border-error/20 bg-error-soft text-error",
		solid: "border-error bg-error text-error-contrast"
	}
};
var iconClasses = {
	info: "text-info",
	success: "text-success",
	warning: "text-warning",
	danger: "text-error"
};
var progressClasses = {
	info: "bg-info",
	success: "bg-success",
	warning: "bg-warning",
	danger: "bg-error"
};
var defaultIcons = {
	info: Info,
	success: CheckCircle2,
	warning: TriangleAlert,
	danger: CircleAlert
};
var Toast = forwardRef(function Toast({ variant = "info", appearance = "default", title, description, icon, loading = false, progress, action, dismissible = true, onDismiss, className, children, role, ...props }, ref) {
	const DefaultIcon = defaultIcons[variant];
	const normalizedProgress = progress === void 0 || !Number.isFinite(progress) ? void 0 : Math.min(100, Math.max(0, progress));
	return /* @__PURE__ */ jsxs("div", {
		...props,
		ref,
		role: role ?? (variant === "danger" ? "alert" : "status"),
		className: cn("flex w-full items-start gap-3 rounded-md border p-4 shadow-md", appearanceClasses[variant][appearance], className),
		children: [
			/* @__PURE__ */ jsx("span", {
				"aria-hidden": "true",
				className: cn("mt-0.5 inline-flex shrink-0", appearance === "default" && iconClasses[variant]),
				children: loading ? /* @__PURE__ */ jsx(LoaderCircle, {
					size: 20,
					className: "animate-spin"
				}) : icon ?? /* @__PURE__ */ jsx(DefaultIcon, { size: 20 })
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex min-w-0 flex-1 flex-col gap-1",
				children: [
					title != null && /* @__PURE__ */ jsx("div", {
						className: "text-body-sm font-semibold",
						children: title
					}),
					description != null && /* @__PURE__ */ jsx("div", {
						className: cn("text-body-sm leading-relaxed", appearance === "default" ? "text-text-secondary" : "opacity-90"),
						children: description
					}),
					children,
					normalizedProgress !== void 0 && /* @__PURE__ */ jsxs("div", {
						className: "mt-2 flex flex-col gap-1.5",
						children: [/* @__PURE__ */ jsxs("span", {
							className: "text-caption",
							children: [Math.round(normalizedProgress), "%"]
						}), /* @__PURE__ */ jsx("div", {
							role: "progressbar",
							"aria-label": "Progresso da operação",
							"aria-valuemin": 0,
							"aria-valuemax": 100,
							"aria-valuenow": normalizedProgress,
							className: cn("h-1.5 w-full overflow-hidden rounded-full", appearance === "solid" ? "bg-white/30" : "bg-border"),
							children: /* @__PURE__ */ jsx("div", {
								className: cn("h-full rounded-full transition-[width]", appearance === "solid" ? "bg-current" : progressClasses[variant]),
								style: { width: `${normalizedProgress}%` }
							})
						})]
					}),
					action && /* @__PURE__ */ jsx("div", {
						className: "mt-2",
						children: /* @__PURE__ */ jsx("button", {
							type: "button",
							onClick: action.onClick,
							className: cn("cursor-pointer rounded-sm text-body-sm", "font-semibold underline-offset-4", "hover:underline", "focus-visible:outline-2", "focus-visible:outline-offset-2", "focus-visible:outline-current"),
							children: action.label
						})
					})
				]
			}),
			dismissible && /* @__PURE__ */ jsx("button", {
				type: "button",
				"aria-label": "Fechar notificação",
				onClick: onDismiss,
				className: cn("inline-flex size-6 shrink-0 items-center", "justify-center rounded-sm opacity-60", "transition-opacity hover:opacity-100", "cursor-pointer", "focus-visible:outline-2", "focus-visible:outline-offset-2", "focus-visible:outline-current"),
				children: /* @__PURE__ */ jsx(X, {
					size: 16,
					"aria-hidden": "true"
				})
			})
		]
	});
});
//#endregion
//#region src/components/feedback/Toast/ToastProvider.tsx
var ToastContext = createContext(null);
var positionClasses = {
	"top-left": "left-4 top-4 items-start",
	"top-center": "left-1/2 top-4 -translate-x-1/2 items-center",
	"top-right": "right-4 top-4 items-end",
	center: "left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 items-center",
	"bottom-left": "bottom-4 left-4 items-start",
	"bottom-center": "bottom-4 left-1/2 -translate-x-1/2 items-center",
	"bottom-right": "bottom-4 right-4 items-end"
};
function ToastItem({ item, defaultDuration, onDismiss }) {
	const duration = item.duration ?? (item.loading ? 0 : defaultDuration);
	const remaining = useRef(duration);
	const startedAt = useRef(0);
	const timer = useRef(null);
	const paused = useRef(false);
	const clearTimer = useCallback(() => {
		if (timer.current !== null) {
			clearTimeout(timer.current);
			timer.current = null;
		}
	}, []);
	const pause = useCallback(() => {
		if (paused.current) return;
		paused.current = true;
		if (timer.current !== null) remaining.current = Math.max(0, remaining.current - (Date.now() - startedAt.current));
		clearTimer();
	}, [clearTimer]);
	const resume = useCallback(() => {
		if (!paused.current) return;
		paused.current = false;
		if (remaining.current <= 0 || duration <= 0) return;
		startedAt.current = Date.now();
		timer.current = setTimeout(() => {
			onDismiss(item.id);
		}, remaining.current);
	}, [
		duration,
		item.id,
		onDismiss
	]);
	useEffect(() => {
		clearTimer();
		remaining.current = duration;
		if (duration > 0 && !paused.current) {
			startedAt.current = Date.now();
			timer.current = setTimeout(() => {
				onDismiss(item.id);
			}, remaining.current);
		}
		return clearTimer;
	}, [
		item.id,
		item.revision,
		duration,
		onDismiss,
		clearTimer
	]);
	return /* @__PURE__ */ jsx("div", {
		className: "pointer-events-auto w-full",
		onMouseEnter: pause,
		onMouseLeave: resume,
		onFocusCapture: pause,
		onBlurCapture: (event) => {
			if (!event.currentTarget.contains(event.relatedTarget)) resume();
		},
		children: /* @__PURE__ */ jsx(Toast, {
			variant: item.variant,
			appearance: item.appearance,
			title: item.title,
			description: item.description,
			icon: item.icon,
			action: item.action,
			loading: item.loading,
			progress: item.progress,
			dismissible: item.dismissible,
			onDismiss: () => onDismiss(item.id)
		})
	});
}
function ToastProvider({ children, position = "bottom-right", duration = 5e3, maxToasts = 5 }) {
	const [items, setItems] = useState([]);
	const nextId = useRef(0);
	const dismiss = useCallback((id) => {
		setItems((current) => current.filter((item) => item.id !== id));
	}, []);
	const dismissAll = useCallback(() => {
		setItems([]);
	}, []);
	const show = useCallback((options) => {
		const id = `toast-${++nextId.current}`;
		const record = {
			...options,
			id,
			revision: 0
		};
		setItems((current) => [...current, record].slice(-Math.max(1, maxToasts)));
		return id;
	}, [maxToasts]);
	const update = useCallback((id, options) => {
		setItems((current) => current.map((item) => item.id === id ? {
			...item,
			...options,
			id,
			revision: item.revision + 1
		} : item));
	}, []);
	const api = {
		show,
		info: useCallback((options) => show({
			...options,
			variant: "info"
		}), [show]),
		success: useCallback((options) => show({
			...options,
			variant: "success"
		}), [show]),
		warning: useCallback((options) => show({
			...options,
			variant: "warning"
		}), [show]),
		danger: useCallback((options) => show({
			...options,
			variant: "danger"
		}), [show]),
		loading: useCallback((options) => show({
			...options,
			variant: options.variant ?? "info",
			loading: true,
			duration: options.duration ?? 0
		}), [show]),
		update,
		dismiss,
		dismissAll
	};
	return /* @__PURE__ */ jsxs(ToastContext.Provider, {
		value: api,
		children: [children, /* @__PURE__ */ jsx("div", {
			className: cn("pointer-events-none fixed z-50", "flex max-h-[calc(100dvh-2rem)]", "w-[calc(100vw-2rem)] max-w-sm", "flex-col gap-3 overflow-y-auto", positionClasses[position]),
			children: items.map((item) => /* @__PURE__ */ jsx(ToastItem, {
				item,
				defaultDuration: duration,
				onDismiss: dismiss
			}, item.id))
		})]
	});
}
function useToast() {
	const context = useContext(ToastContext);
	if (!context) throw new Error("useToast must be used inside ToastProvider.");
	return context;
}
//#endregion
//#region src/components/overlays/Dialog/Dialog.tsx
var Dialog = DialogPrimitive.Root;
var DialogTrigger = DialogPrimitive.Trigger;
var DialogClose = DialogPrimitive.Close;
var sizeClasses$2 = {
	sm: "max-w-sm",
	md: "max-w-lg",
	lg: "max-w-2xl",
	xl: "max-w-4xl"
};
var DialogOverlay = forwardRef(function DialogOverlay({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx(DialogPrimitive.Overlay, {
		ref,
		className: cn("fixed inset-0 z-50 bg-black/50", "data-[state=open]:animate-in", "data-[state=closed]:animate-out", className),
		...props
	});
});
var DialogContent = forwardRef(function DialogContent({ className, children, size = "md", closeOnOverlayClick = true, closeOnEscape = true, showCloseButton = true, onPointerDownOutside, onEscapeKeyDown, ...props }, ref) {
	return /* @__PURE__ */ jsxs(DialogPrimitive.Portal, { children: [/* @__PURE__ */ jsx(DialogOverlay, {}), /* @__PURE__ */ jsxs(DialogPrimitive.Content, {
		ref,
		className: cn("fixed left-1/2 top-1/2 z-50", "flex max-h-[calc(100dvh-2rem)]", "w-[calc(100vw-2rem)] flex-col", "-translate-x-1/2 -translate-y-1/2", "overflow-hidden rounded-md", "border border-border bg-surface", "text-text-primary shadow-lg", "focus:outline-none", sizeClasses$2[size], className),
		onPointerDownOutside: (event) => {
			onPointerDownOutside?.(event);
			if (!closeOnOverlayClick) event.preventDefault();
		},
		onEscapeKeyDown: (event) => {
			onEscapeKeyDown?.(event);
			if (!closeOnEscape) event.preventDefault();
		},
		...props,
		children: [children, showCloseButton && /* @__PURE__ */ jsx(DialogPrimitive.Close, {
			"aria-label": "Fechar diálogo",
			className: cn("absolute right-4 top-4", "inline-flex size-7 items-center justify-center", "rounded-sm text-text-secondary", "transition-colors", "hover:bg-background hover:text-text-primary", "focus-visible:outline-2", "focus-visible:outline-offset-2", "focus-visible:outline-primary", "cursor-pointer"),
			children: /* @__PURE__ */ jsx(X, {
				size: 18,
				"aria-hidden": "true"
			})
		})]
	})] });
});
var DialogHeader = forwardRef(function DialogHeader({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("div", {
		ref,
		className: cn("flex shrink-0 flex-col gap-1.5 px-6 pt-6 pb-4", className),
		...props,
		children
	});
});
var DialogTitle = forwardRef(function DialogTitle({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx(DialogPrimitive.Title, {
		ref,
		className: cn("heading-sm pr-8 text-text-primary", className),
		...props
	});
});
var DialogDescription = forwardRef(function DialogDescription({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx(DialogPrimitive.Description, {
		ref,
		className: cn("text-body-sm text-text-secondary", className),
		...props
	});
});
var DialogBody = forwardRef(function DialogBody({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("div", {
		ref,
		className: cn("min-h-0 flex-1 overflow-y-auto px-6 py-4", className),
		...props,
		children
	});
});
var DialogFooter = forwardRef(function DialogFooter({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("div", {
		ref,
		className: cn("flex shrink-0 flex-wrap items-center", "justify-end gap-3 px-6 py-4", "border-t border-border", className),
		...props,
		children
	});
});
//#endregion
//#region src/components/overlays/Drawer/Drawer.tsx
var Drawer = DialogPrimitive.Root;
var DrawerTrigger = DialogPrimitive.Trigger;
var DrawerClose = DialogPrimitive.Close;
var horizontalSizes = {
	sm: "max-w-xs",
	md: "max-w-md",
	lg: "max-w-xl",
	xl: "max-w-2xl"
};
var verticalSizes = {
	sm: "max-h-48",
	md: "max-h-80",
	lg: "max-h-[32rem]",
	xl: "max-h-[40rem]"
};
var sideClasses = {
	left: [
		"inset-y-0 left-0 h-full w-[calc(100vw-1rem)]",
		"border-r border-border",
		"data-[state=open]:animate-[drawer-in-left_250ms_ease-out]",
		"data-[state=closed]:animate-[drawer-out-left_200ms_ease-in]"
	].join(" "),
	right: [
		"inset-y-0 right-0 h-full w-[calc(100vw-1rem)]",
		"border-l border-border",
		"data-[state=open]:animate-[drawer-in-right_250ms_ease-out]",
		"data-[state=closed]:animate-[drawer-out-right_200ms_ease-in]"
	].join(" "),
	top: [
		"inset-x-0 top-0 w-full h-[calc(100dvh-1rem)]",
		"border-b border-border",
		"data-[state=open]:animate-[drawer-in-top_250ms_ease-out]",
		"data-[state=closed]:animate-[drawer-out-top_200ms_ease-in]"
	].join(" "),
	bottom: [
		"inset-x-0 bottom-0 w-full h-[calc(100dvh-1rem)]",
		"border-t border-border",
		"data-[state=open]:animate-[drawer-in-bottom_250ms_ease-out]",
		"data-[state=closed]:animate-[drawer-out-bottom_200ms_ease-in]"
	].join(" ")
};
var DrawerOverlay = forwardRef(function DrawerOverlay({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx(DialogPrimitive.Overlay, {
		ref,
		className: cn("fixed inset-0 z-50 bg-black/40", "data-[state=open]:animate-[drawer-overlay-in_250ms_ease-out]", "data-[state=closed]:animate-[drawer-overlay-out_200ms_ease-in]", "motion-reduce:animate-none", className),
		...props
	});
});
var DrawerContent = forwardRef(function DrawerContent({ className, children, side = "right", size = "md", showCloseButton = true, closeOnOverlayClick = true, closeOnEscape = true, onPointerDownOutside, onEscapeKeyDown, ...props }, ref) {
	const isHorizontal = side === "left" || side === "right";
	return /* @__PURE__ */ jsxs(DialogPrimitive.Portal, { children: [/* @__PURE__ */ jsx(DrawerOverlay, {}), /* @__PURE__ */ jsxs(DialogPrimitive.Content, {
		...props,
		ref,
		onPointerDownOutside: (event) => {
			onPointerDownOutside?.(event);
			if (!closeOnOverlayClick) event.preventDefault();
		},
		onEscapeKeyDown: (event) => {
			onEscapeKeyDown?.(event);
			if (!closeOnEscape) event.preventDefault();
		},
		className: cn("fixed z-50 flex flex-col overflow-hidden", "bg-surface text-text-primary shadow-lg", "focus:outline-none", "motion-reduce:animate-none", sideClasses[side], isHorizontal ? horizontalSizes[size] : verticalSizes[size], className),
		children: [children, showCloseButton && /* @__PURE__ */ jsx(DialogPrimitive.Close, {
			type: "button",
			"aria-label": "Fechar painel",
			className: cn("absolute right-4 top-4 z-10", "inline-flex size-8 items-center justify-center", "rounded-sm text-text-secondary", "transition-colors", "hover:bg-background hover:text-text-primary", "focus-visible:outline-2", "focus-visible:outline-offset-2", "focus-visible:outline-primary", "cursor-pointer"),
			children: /* @__PURE__ */ jsx(X, {
				size: 18,
				"aria-hidden": "true"
			})
		})]
	})] });
});
var DrawerHeader = forwardRef(function DrawerHeader({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("div", {
		...props,
		ref,
		className: cn("flex shrink-0 flex-col gap-1.5", "border-b border-border px-6 py-5", className),
		children
	});
});
var DrawerTitle = forwardRef(function DrawerTitle({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx(DialogPrimitive.Title, {
		...props,
		ref,
		className: cn("heading-sm pr-8 text-text-primary", className)
	});
});
var DrawerDescription = forwardRef(function DrawerDescription({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx(DialogPrimitive.Description, {
		...props,
		ref,
		className: cn("text-body-sm text-text-secondary", className)
	});
});
var DrawerBody = forwardRef(function DrawerBody({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("div", {
		...props,
		ref,
		className: cn("min-h-0 flex-1 overflow-y-auto px-6 py-5", className),
		children
	});
});
var DrawerFooter = forwardRef(function DrawerFooter({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("div", {
		...props,
		ref,
		className: cn("flex shrink-0 flex-wrap items-center", "justify-end gap-3 border-t border-border", "px-6 py-4", className),
		children
	});
});
//#endregion
//#region src/components/feedback/Skeleton/Skeleton.tsx
var variantClasses = {
	text: "rounded-sm",
	rectangle: "rounded-none",
	rounded: "rounded-md",
	circle: "rounded-full"
};
var animationClasses = {
	pulse: "animate-pulse motion-reduce:animate-none",
	wave: "bacurim-skeleton-wave",
	none: ""
};
var defaultHeights = {
	text: "1em",
	rectangle: "1rem",
	rounded: "1rem",
	circle: "2.5rem"
};
var Skeleton = forwardRef(function Skeleton({ variant = "rounded", animation = "pulse", width, height, className, style, ...props }, ref) {
	const dimensions = {
		width: width ?? (variant === "circle" ? "2.5rem" : "100%"),
		height: height ?? defaultHeights[variant]
	};
	return /* @__PURE__ */ jsx("span", {
		...props,
		ref,
		"aria-hidden": "true",
		className: cn("relative block shrink-0 overflow-hidden", "bg-border", variantClasses[variant], animationClasses[animation], className),
		style: {
			...dimensions,
			...style
		}
	});
});
//#endregion
//#region src/components/feedback/EmptyState/EmptyState.tsx
var containerSizes = {
	sm: "gap-3 px-4 py-6",
	md: "gap-4 px-6 py-10",
	lg: "gap-5 px-8 py-14"
};
var EmptyState = forwardRef(function EmptyState({ size = "md", className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("div", {
		...props,
		ref,
		"data-size": size,
		className: cn("flex w-full flex-col items-center", "justify-center text-center", containerSizes[size], className),
		children
	});
});
var EmptyStateIcon = forwardRef(function EmptyStateIcon({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("div", {
		...props,
		ref,
		"aria-hidden": "true",
		className: cn("flex shrink-0 items-center justify-center", "rounded-full bg-primary-soft text-primary", "size-16", "[[data-size=sm]_&]:size-12", "[[data-size=lg]_&]:size-20", "[&>svg]:size-7", "[[data-size=sm]_&>svg]:size-5", "[[data-size=lg]_&>svg]:size-9", className),
		children
	});
});
var EmptyStateTitle = forwardRef(function EmptyStateTitle({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("h3", {
		...props,
		ref,
		className: cn("text-text-primary", "text-body-md font-semibold", "[[data-size=md]_&]:heading-sm", "[[data-size=lg]_&]:heading-md", className),
		children
	});
});
var EmptyStateDescription = forwardRef(function EmptyStateDescription({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("p", {
		...props,
		ref,
		className: cn("max-w-md text-body-sm text-text-secondary", "[[data-size=lg]_&]:text-body-md", className),
		children
	});
});
var EmptyStateActions = forwardRef(function EmptyStateActions({ className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx("div", {
		...props,
		ref,
		className: cn("mt-2 flex flex-wrap items-center", "justify-center gap-3", className),
		children
	});
});
//#endregion
//#region src/components/feedback/Progress/Progress.tsx
var colorClasses = {
	primary: "bg-primary",
	secondary: "bg-secondary",
	success: "bg-success",
	warning: "bg-warning",
	error: "bg-error",
	info: "bg-info"
};
var sizeClasses$1 = {
	sm: "h-1",
	md: "h-2",
	lg: "h-5"
};
var radiusClasses = {
	none: "rounded-none",
	sm: "rounded-sm",
	md: "rounded-md",
	full: "rounded-full"
};
var clamp = (value, min, max) => Math.min(Math.max(value, min), max);
var formatNumber$1 = (value) => new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 1 }).format(value);
var Progress = forwardRef(function Progress({ value = 0, min = 0, max = 100, indeterminate = false, color = "primary", size = "md", radius = "full", label, showValue = false, labelPosition = "end", valueFormat = "percentage", className, ...props }, ref) {
	const generatedId = useId();
	const safeMin = Number.isFinite(min) ? min : 0;
	const safeMax = Number.isFinite(max) && max > safeMin ? max : safeMin + 100;
	const safeValue = clamp(Number.isFinite(value) ? value : safeMin, safeMin, safeMax);
	const percentage = (safeValue - safeMin) / (safeMax - safeMin) * 100;
	const formattedValue = valueFormat === "value" ? formatNumber$1(safeValue) : `${formatNumber$1(percentage)}%`;
	const hasTopLabel = Boolean(label) || showValue && labelPosition === "top";
	const valueId = `${generatedId}-value`;
	const labelId = `${generatedId}-label`;
	const progressStyle = { "--progress-value": `${percentage}%` };
	const valueElement = /* @__PURE__ */ jsx("span", {
		id: valueId,
		className: "shrink-0 text-body-sm tabular-nums text-text-secondary",
		children: formattedValue
	});
	return /* @__PURE__ */ jsxs("div", {
		ref,
		className: cn("flex w-full flex-col gap-2", className),
		...props,
		children: [hasTopLabel && /* @__PURE__ */ jsxs("div", {
			className: "flex items-center justify-between gap-3",
			children: [label ? /* @__PURE__ */ jsx("span", {
				id: labelId,
				className: "text-body-sm font-medium text-text-primary",
				children: label
			}) : /* @__PURE__ */ jsx("span", {}), showValue && labelPosition === "top" && !indeterminate && valueElement]
		}), /* @__PURE__ */ jsxs("div", {
			className: "flex w-full items-center gap-3",
			children: [/* @__PURE__ */ jsxs("div", {
				className: cn("relative min-w-0 flex-1", labelPosition === "floating" && showValue && !indeterminate && "pt-7"),
				children: [showValue && labelPosition === "floating" && !indeterminate && /* @__PURE__ */ jsx("div", {
					className: "bacurim-progress-floating-label",
					style: progressStyle,
					children: /* @__PURE__ */ jsx("span", {
						className: "bacurim-progress-floating-value",
						children: formattedValue
					})
				}), /* @__PURE__ */ jsx("div", {
					role: "progressbar",
					"aria-label": label || "Progresso",
					"aria-valuemin": indeterminate ? void 0 : safeMin,
					"aria-valuemax": indeterminate ? void 0 : safeMax,
					"aria-valuenow": indeterminate ? void 0 : safeValue,
					"aria-valuetext": indeterminate ? void 0 : valueFormat === "percentage" ? formattedValue : void 0,
					"aria-busy": indeterminate || void 0,
					className: cn("relative w-full overflow-hidden bg-border", sizeClasses$1[size], radiusClasses[radius]),
					children: /* @__PURE__ */ jsx("div", {
						className: cn("relative h-full", "transition-[width] duration-300 ease-out", "motion-reduce:transition-none", colorClasses[color], radiusClasses[radius], indeterminate ? "bacurim-progress-indeterminate" : "bacurim-progress-determinate"),
						style: indeterminate ? void 0 : { width: `${percentage}%` },
						children: showValue && labelPosition === "inside" && !indeterminate && percentage > 0 && /* @__PURE__ */ jsx("span", {
							className: cn("absolute inset-0 flex items-center", "justify-center whitespace-nowrap", "text-xs font-medium", "text-white tabular-nums", percentage < 15 && "sr-only"),
							children: formattedValue
						})
					})
				})]
			}), showValue && labelPosition === "end" && !indeterminate && valueElement]
		})]
	});
});
//#endregion
//#region src/components/data-display/Table/Table.tsx
var TableContext = createContext({
	density: "default",
	variant: "default",
	striped: false,
	stripeColor: "neutral",
	hoverable: false,
	hoverColor: "neutral"
});
var densityClasses = {
	compact: "px-3 py-2",
	default: "px-4 py-3",
	comfortable: "px-5 py-4"
};
var alignClasses = {
	left: "text-left",
	center: "text-center",
	right: "text-right"
};
var highlightClasses = {
	neutral: "bg-background",
	success: "bg-success-soft",
	warning: "bg-warning-soft",
	error: "bg-error-soft",
	info: "bg-info-soft"
};
var hoverClasses = {
	neutral: "hover:bg-background",
	success: "hover:bg-success-soft",
	warning: "hover:bg-warning-soft",
	error: "hover:bg-error-soft",
	info: "hover:bg-info-soft"
};
var stripeClasses = {
	neutral: "even:bg-background",
	success: "even:bg-success-soft",
	warning: "even:bg-warning-soft",
	error: "even:bg-error-soft",
	info: "even:bg-info-soft"
};
var Table = forwardRef(function Table({ density = "default", variant = "default", striped = false, stripeColor = "neutral", hoverable = false, hoverColor = "neutral", className, children, ...props }, ref) {
	return /* @__PURE__ */ jsx(TableContext.Provider, {
		value: {
			density,
			variant,
			striped,
			stripeColor,
			hoverable,
			hoverColor
		},
		children: /* @__PURE__ */ jsx("table", {
			...props,
			ref,
			className: cn("w-full caption-bottom border-collapse", "text-body-sm text-text-primary", variant === "bordered" && "border border-border", className),
			children
		})
	});
});
var TableHeader = forwardRef(function TableHeader({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx("thead", {
		...props,
		ref,
		className: cn("bg-surface", "[&_tr]:border-b [&_tr]:border-border", className)
	});
});
var TableBody = forwardRef(function TableBody({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx("tbody", {
		...props,
		ref,
		className: cn("[&_tr:last-child]:border-b-0", className)
	});
});
var TableFooter = forwardRef(function TableFooter({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx("tfoot", {
		...props,
		ref,
		className: cn("border-t border-border bg-background", "font-medium", className)
	});
});
var TableRow = forwardRef(function TableRow({ selected = false, highlight, interactive = false, className, onClick, onKeyDown, tabIndex, ...props }, ref) {
	const { striped, stripeColor, hoverable, hoverColor, variant } = useContext(TableContext);
	const isInteractive = interactive || Boolean(onClick);
	const handleKeyDown = (event) => {
		onKeyDown?.(event);
		if (event.defaultPrevented || !isInteractive || !onClick) return;
		if (event.key === "Enter" || event.key === " ") {
			event.preventDefault();
			event.currentTarget.click();
		}
	};
	return /* @__PURE__ */ jsx("tr", {
		...props,
		ref,
		"aria-selected": selected || void 0,
		tabIndex: isInteractive ? tabIndex ?? 0 : tabIndex,
		onClick,
		onKeyDown: handleKeyDown,
		className: cn("border-b border-border", "transition-colors", "motion-reduce:transition-none", variant === "bordered" && "[&>td]:border [&>td]:border-border", striped && stripeClasses[stripeColor], hoverable && hoverClasses[hoverColor], highlight && highlightClasses[highlight], selected && "bg-primary-soft", isInteractive && "cursor-pointer focus-visible:outline-2", isInteractive && "focus-visible:outline-offset-[-2px]", isInteractive && "focus-visible:outline-primary", className)
	});
});
var TableHead = forwardRef(function TableHead({ align = "left", highlight, className, scope = "col", ...props }, ref) {
	const { density, variant } = useContext(TableContext);
	return /* @__PURE__ */ jsx("th", {
		...props,
		ref,
		scope,
		className: cn("font-medium text-text-secondary", "align-middle", densityClasses[density], alignClasses[align], variant === "bordered" && "border border-border", highlight && highlightClasses[highlight], className)
	});
});
var TableCell = forwardRef(function TableCell({ align = "left", highlight, className, ...props }, ref) {
	const { density, variant } = useContext(TableContext);
	return /* @__PURE__ */ jsx("td", {
		...props,
		ref,
		className: cn("align-middle", densityClasses[density], alignClasses[align], variant === "bordered" && "border border-border", highlight && highlightClasses[highlight], className)
	});
});
var TableCaption = forwardRef(function TableCaption({ className, ...props }, ref) {
	return /* @__PURE__ */ jsx("caption", {
		...props,
		ref,
		className: cn("mt-3 text-body-sm text-text-secondary", className)
	});
});
//#endregion
//#region src/components/data-display/Table/TableSortHead.tsx
function getNextSortDirection(current, allowUnsort = true) {
	if (current === null) return "asc";
	if (current === "asc") return "desc";
	return allowUnsort ? null : "asc";
}
var sortLabels = {
	asc: "crescente",
	desc: "decrescente"
};
var TableSortHead = forwardRef(function TableSortHead({ children, sortDirection = null, onSortChange, allowUnsort = true, disabled = false, align = "left", className, ...props }, ref) {
	const isSorted = sortDirection !== null;
	const nextDirection = getNextSortDirection(sortDirection, allowUnsort);
	const SortIcon = sortDirection === "asc" ? ArrowUp : sortDirection === "desc" ? ArrowDown : ArrowUpDown;
	const handleSort = () => {
		if (disabled) return;
		onSortChange?.(nextDirection);
	};
	const nextAction = nextDirection === null ? "Remover ordenação" : `Ordenar ${sortLabels[nextDirection]}`;
	return /* @__PURE__ */ jsx(TableHead, {
		...props,
		ref,
		align,
		"aria-sort": sortDirection === "asc" ? "ascending" : sortDirection === "desc" ? "descending" : void 0,
		className: cn(className),
		children: /* @__PURE__ */ jsxs("button", {
			type: "button",
			disabled,
			onClick: handleSort,
			className: cn("group inline-flex w-full items-center gap-2", "rounded-sm text-inherit", "transition-colors", "motion-reduce:transition-none", "focus-visible:outline-2", "focus-visible:outline-offset-2", "focus-visible:outline-primary", "disabled:cursor-not-allowed", "disabled:opacity-50", align === "left" && "justify-start", align === "center" && "justify-center", align === "right" && "justify-end", !disabled && "cursor-pointer", !disabled && "hover:text-primary"),
			"aria-label": nextAction,
			children: [/* @__PURE__ */ jsx("span", { children }), /* @__PURE__ */ jsx(SortIcon, {
				size: 14,
				"aria-hidden": "true",
				className: cn("shrink-0 transition-colors", "motion-reduce:transition-none", isSorted ? "text-primary" : "text-text-secondary")
			})]
		})
	});
});
//#endregion
//#region src/components/navigation/Pagination/Pagination.tsx
var sizeClasses = {
	sm: "size-8 text-xs",
	md: "size-9 text-body-sm",
	lg: "size-11 text-body-md"
};
var buttonBase = cn("inline-flex shrink-0 items-center justify-center", "rounded-sm font-medium", "transition-colors", "motion-reduce:transition-none", "focus-visible:outline-2", "focus-visible:outline-offset-2", "focus-visible:outline-primary", "disabled:pointer-events-none", "disabled:opacity-40");
function range(start, end) {
	return Array.from({ length: Math.max(0, end - start + 1) }, (_, index) => start + index);
}
function getPaginationItems({ page, totalPages, siblingCount = 1, boundaryCount = 1 }) {
	const total = Math.max(0, Math.floor(totalPages));
	const current = Math.min(Math.max(1, Math.floor(page)), Math.max(1, total));
	const siblings = Math.max(0, Math.floor(siblingCount));
	const boundaries = Math.max(0, Math.floor(boundaryCount));
	if (total === 0) return [];
	const startPages = range(1, Math.min(boundaries, total));
	const endPages = range(Math.max(total - boundaries + 1, boundaries + 1), total);
	const siblingsStart = Math.max(Math.min(current - siblings, total - boundaries - siblings * 2 - 1), boundaries + 2);
	const siblingsEnd = Math.min(Math.max(current + siblings, boundaries + siblings * 2 + 2), total - boundaries - 1);
	const items = [...startPages];
	if (siblingsStart > boundaries + 2) items.push("start-ellipsis");
	else if (boundaries + 1 < total - boundaries) items.push(boundaries + 1);
	items.push(...range(siblingsStart, siblingsEnd));
	if (siblingsEnd < total - boundaries - 1) items.push("end-ellipsis");
	else if (total - boundaries > boundaries) items.push(total - boundaries);
	items.push(...endPages);
	return [...new Set(items)];
}
function NavigationButton({ label, disabled, onClick, size, variant, children }) {
	return /* @__PURE__ */ jsx("button", {
		type: "button",
		"aria-label": label,
		disabled,
		onClick,
		className: cn(buttonBase, sizeClasses[size], "text-text-secondary", variant === "outline" ? "border border-border bg-surface hover:bg-background" : "hover:bg-background"),
		children
	});
}
var Pagination = forwardRef(function Pagination({ page, totalPages, onPageChange, siblingCount = 1, boundaryCount = 1, showFirstLast = true, showPreviousNext = true, size = "md", variant = "default", disabled = false, className, ...props }, ref) {
	const total = Number.isFinite(totalPages) ? Math.max(0, Math.floor(totalPages)) : 0;
	const current = Number.isFinite(page) ? Math.min(Math.max(1, Math.floor(page)), Math.max(1, total)) : 1;
	const hasPages = total > 0;
	const items = getPaginationItems({
		page: current,
		totalPages: total,
		siblingCount,
		boundaryCount
	});
	const navigate = (nextPage) => {
		if (disabled || !hasPages || nextPage < 1 || nextPage > total || nextPage === current) return;
		onPageChange(nextPage);
	};
	const previousDisabled = disabled || !hasPages || current <= 1;
	const nextDisabled = disabled || !hasPages || current >= total;
	return /* @__PURE__ */ jsxs("nav", {
		...props,
		ref,
		"aria-label": props["aria-label"] ?? "Paginação",
		className: cn("flex flex-wrap items-center justify-center gap-1", className),
		children: [
			showFirstLast && /* @__PURE__ */ jsx(NavigationButton, {
				label: "Primeira página",
				disabled: previousDisabled,
				onClick: () => navigate(1),
				size,
				variant,
				children: /* @__PURE__ */ jsx(ChevronsLeft, {
					size: 16,
					"aria-hidden": "true"
				})
			}),
			showPreviousNext && /* @__PURE__ */ jsx(NavigationButton, {
				label: "Página anterior",
				disabled: previousDisabled,
				onClick: () => navigate(current - 1),
				size,
				variant,
				children: /* @__PURE__ */ jsx(ChevronLeft, {
					size: 16,
					"aria-hidden": "true"
				})
			}),
			items.map((item) => {
				if (typeof item !== "number") return /* @__PURE__ */ jsx("span", {
					"aria-hidden": "true",
					className: cn("inline-flex items-center justify-center", "text-text-secondary", sizeClasses[size]),
					children: "…"
				}, item);
				const isCurrent = item === current;
				return /* @__PURE__ */ jsx("button", {
					type: "button",
					"aria-label": `Página ${item}`,
					"aria-current": isCurrent ? "page" : void 0,
					disabled: disabled || isCurrent,
					onClick: () => navigate(item),
					className: cn(buttonBase, sizeClasses[size], isCurrent ? "bg-primary text-primary-contrast" : "text-text-secondary", !isCurrent && variant === "outline" && "border border-border bg-surface", !isCurrent && "hover:bg-background", isCurrent && "disabled:opacity-100"),
					children: item
				}, item);
			}),
			showPreviousNext && /* @__PURE__ */ jsx(NavigationButton, {
				label: "Próxima página",
				disabled: nextDisabled,
				onClick: () => navigate(current + 1),
				size,
				variant,
				children: /* @__PURE__ */ jsx(ChevronRight, {
					size: 16,
					"aria-hidden": "true"
				})
			}),
			showFirstLast && /* @__PURE__ */ jsx(NavigationButton, {
				label: "Última página",
				disabled: nextDisabled,
				onClick: () => navigate(total),
				size,
				variant,
				children: /* @__PURE__ */ jsx(ChevronsRight, {
					size: 16,
					"aria-hidden": "true"
				})
			})
		]
	});
});
//#endregion
//#region src/components/forms/SearchInput/SearchInput.tsx
var SearchInput = forwardRef(function SearchInput({ value, defaultValue, onChange, onClear, clearable = true, clearLabel = "Limpar busca", disabled = false, readOnly = false, placeholder = "Pesquisar...", size = "md", className, ...props }, forwardedRef) {
	const internalRef = useRef(null);
	const [internalValue, setInternalValue] = useState(String(defaultValue ?? ""));
	const isControlled = value !== void 0;
	const currentValue = isControlled ? String(value ?? "") : internalValue;
	const canClear = clearable && !disabled && !readOnly && currentValue.length > 0;
	useImperativeHandle(forwardedRef, () => internalRef.current);
	const handleChange = (event) => {
		if (!isControlled) setInternalValue(event.target.value);
		onChange?.(event);
	};
	const handleClear = () => {
		if (disabled || readOnly) return;
		if (!isControlled) setInternalValue("");
		onClear?.();
		internalRef.current?.focus();
	};
	return /* @__PURE__ */ jsx(Input, {
		...props,
		ref: internalRef,
		type: "text",
		inputMode: "search",
		value: currentValue,
		onChange: handleChange,
		disabled,
		readOnly,
		placeholder,
		size,
		className,
		startIcon: /* @__PURE__ */ jsx(Search, { "aria-hidden": "true" }),
		endAdornment: canClear ? /* @__PURE__ */ jsx("button", {
			type: "button",
			"aria-label": clearLabel,
			onClick: handleClear,
			className: cn("inline-flex size-7 shrink-0", "items-center justify-center", "rounded-sm text-text-secondary", "transition-colors", "hover:bg-background", "hover:text-text-primary", "focus-visible:outline-2", "focus-visible:outline-offset-2", "focus-visible:outline-primary", "motion-reduce:transition-none"),
			children: /* @__PURE__ */ jsx(X, {
				size: 16,
				"aria-hidden": "true"
			})
		}) : void 0
	});
});
//#endregion
//#region src/components/data-display/FilterBar/FilterBar.tsx
var FilterBarContext = createContext(null);
function useFilterBarContext() {
	const context = useContext(FilterBarContext);
	if (!context) throw new Error("FilterBarContent e FilterBarActions devem ser utilizados dentro de FilterBar.");
	return context;
}
var FilterBar = forwardRef(function FilterBar({ activeFiltersCount = 0, onClear, clearLabel = "Limpar filtros", showClearButton = true, showActiveCount = true, title = "Filtros", children, className, ...props }, ref) {
	const count = Math.max(0, Math.trunc(Number.isFinite(activeFiltersCount) ? activeFiltersCount : 0));
	const hasActiveFilters = count > 0;
	const showHeader = Boolean(title) || showActiveCount && hasActiveFilters || showClearButton && Boolean(onClear);
	return /* @__PURE__ */ jsx(FilterBarContext.Provider, {
		value: { hasActiveFilters },
		children: /* @__PURE__ */ jsxs("div", {
			...props,
			ref,
			className: cn("flex w-full flex-col gap-4", "rounded-md border border-border", "bg-surface p-4", className),
			children: [showHeader && /* @__PURE__ */ jsxs("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "flex min-w-0 items-center gap-2",
					children: [title && /* @__PURE__ */ jsx("span", {
						className: "text-body-sm font-semibold text-text-primary",
						children: title
					}), showActiveCount && hasActiveFilters && /* @__PURE__ */ jsxs("span", {
						className: cn("inline-flex min-h-6 items-center", "rounded-full bg-primary-soft px-2.5", "text-body-sm font-medium text-primary"),
						"aria-label": `${count} filtro${count === 1 ? "" : "s"} ativo${count === 1 ? "" : "s"}`,
						children: [
							count,
							" ativo",
							count === 1 ? "" : "s"
						]
					})]
				}), showClearButton && onClear && /* @__PURE__ */ jsxs("button", {
					type: "button",
					onClick: onClear,
					disabled: !hasActiveFilters,
					className: cn("inline-flex min-h-9 items-center justify-center gap-2", "rounded-sm px-3 text-body-sm font-medium", "text-text-secondary transition-colors", "hover:bg-background hover:text-text-primary", "focus-visible:outline-2", "focus-visible:outline-offset-2", "focus-visible:outline-primary", "disabled:cursor-not-allowed", "disabled:opacity-50", "motion-reduce:transition-none"),
					children: [/* @__PURE__ */ jsx(RotateCcw, {
						size: 16,
						"aria-hidden": "true"
					}), clearLabel]
				})]
			}), children]
		})
	});
});
var columnClasses = {
	1: "md:grid-cols-1",
	2: "md:grid-cols-2",
	3: "md:grid-cols-2 xl:grid-cols-3",
	4: "md:grid-cols-2 xl:grid-cols-4"
};
var FilterBarContent = forwardRef(function FilterBarContent({ columns = 3, children, className, ...props }, ref) {
	useFilterBarContext();
	return /* @__PURE__ */ jsx("div", {
		...props,
		ref,
		className: cn("grid w-full grid-cols-1 items-end gap-3", columnClasses[columns], className),
		children
	});
});
var alignmentClasses = {
	start: "justify-start",
	center: "justify-center",
	end: "justify-end"
};
var FilterBarActions = forwardRef(function FilterBarActions({ align = "end", children, className, ...props }, ref) {
	useFilterBarContext();
	return /* @__PURE__ */ jsx("div", {
		...props,
		className: cn("flex flex-wrap items-center gap-2", "border-t border-border pt-4", alignmentClasses[align], className),
		ref,
		children
	});
});
//#endregion
//#region src/utilities/formatters/number.ts
function formatNumber(value, { locale = "pt-BR", fallback = "—", ...options } = {}) {
	if (value == null || !Number.isFinite(value)) return fallback;
	return new Intl.NumberFormat(locale, {
		maximumFractionDigits: 2,
		...options
	}).format(value);
}
//#endregion
//#region src/utilities/formatters/currency.ts
function formatCurrency(value, { locale = "pt-BR", currency = "BRL", fallback = "—", ...options } = {}) {
	if (value == null || !Number.isFinite(value)) return fallback;
	return new Intl.NumberFormat(locale, {
		...options,
		style: "currency",
		currency
	}).format(value);
}
//#endregion
//#region src/utilities/formatters/percentage.ts
function formatPercentage(value, { locale = "pt-BR", fallback = "—", ...options } = {}) {
	if (value == null || !Number.isFinite(value)) return fallback;
	return new Intl.NumberFormat(locale, {
		minimumFractionDigits: 0,
		maximumFractionDigits: 2,
		...options,
		style: "percent"
	}).format(value);
}
//#endregion
//#region src/utilities/formatters/date.ts
var DATE_ONLY_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/;
function parseDate(value) {
	if (value instanceof Date) {
		if (Number.isNaN(value.getTime())) return null;
		return {
			date: value,
			dateOnly: false
		};
	}
	if (typeof value === "number") {
		if (!Number.isFinite(value)) return null;
		const date = new Date(value);
		if (Number.isNaN(date.getTime())) return null;
		return {
			date,
			dateOnly: false
		};
	}
	const match = DATE_ONLY_PATTERN.exec(value);
	if (match) {
		const year = Number(match[1]);
		const month = Number(match[2]);
		const day = Number(match[3]);
		const date = /* @__PURE__ */ new Date(0);
		date.setUTCFullYear(year, month - 1, day);
		date.setUTCHours(0, 0, 0, 0);
		if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) return null;
		return {
			date,
			dateOnly: true
		};
	}
	const timestamp = Date.parse(value);
	if (Number.isNaN(timestamp)) return null;
	return {
		date: new Date(timestamp),
		dateOnly: false
	};
}
function formatDate(value, { locale = "pt-BR", fallback = "—", ...options } = {}) {
	if (value == null || value === "") return fallback;
	const parsed = parseDate(value);
	if (!parsed) return fallback;
	const { timeZone, ...formatOptions } = options;
	const formatterOptions = {
		...formatOptions.dateStyle !== void 0 || formatOptions.timeStyle !== void 0 ? {} : {
			day: "2-digit",
			month: "2-digit",
			year: "numeric"
		},
		...formatOptions,
		timeZone: parsed.dateOnly ? "UTC" : timeZone
	};
	return new Intl.DateTimeFormat(locale, formatterOptions).format(parsed.date);
}
//#endregion
//#region src/components/data-display/FormattedValue/FormattedValue.tsx
var FormattedValue = forwardRef(function FormattedValue(props, ref) {
	const { className, ...rest } = props;
	let formattedValue;
	switch (rest.type) {
		case "number":
			formattedValue = formatNumber(rest.value, rest.options);
			break;
		case "currency":
			formattedValue = formatCurrency(rest.value, rest.options);
			break;
		case "percentage":
			formattedValue = formatPercentage(rest.value, rest.options);
			break;
		case "date": formattedValue = formatDate(rest.value, rest.options);
	}
	const { type: _type, value: _value, options: _options, ...spanProps } = rest;
	return /* @__PURE__ */ jsx("span", {
		...spanProps,
		ref,
		className: cn("tabular-nums", className),
		children: formattedValue
	});
});
//#endregion
export { Alert, AlertActions, AlertContent, AlertDescription, AlertIcon, AlertTitle, AppShell, Avatar, AvatarFallback, AvatarImage, Badge, Button, Card, CardContent, CardDescription, CardFooter, CardHeader, CardMedia, CardTitle, Checkbox, ContentLayout, DateInput, Dialog, DialogBody, DialogClose, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogOverlay, DialogTitle, DialogTrigger, Drawer, DrawerBody, DrawerClose, DrawerContent, DrawerDescription, DrawerFooter, DrawerHeader, DrawerOverlay, DrawerTitle, DrawerTrigger, DropdownMenu, DropdownMenuContent, DropdownMenuGroup, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger, EmptyState, EmptyStateActions, EmptyStateDescription, EmptyStateIcon, EmptyStateTitle, FilterBar, FilterBarActions, FilterBarContent, FormField, FormFieldControl, FormFieldDescription, FormFieldError, FormFieldLabel, FormattedValue, Header, Input, MoneyInput, Pagination, Progress, RadioGroup, RadioGroupItem, SearchInput, Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectScrollDownButton, SelectScrollUpButton, SelectSeparator, SelectTrigger, SelectValue, Separator, Sidebar, Skeleton, Table, TableBody, TableCaption, TableCell, TableFooter, TableHead, TableHeader, TableRow, TableSortHead, Tabs, TabsContent, TabsList, TabsTrigger, Textarea, Toast, ToastProvider, Tooltip, TooltipContent, TooltipProvider, TooltipTrigger, cn, formatCurrency, formatDate, formatNumber, formatPercentage, getNextSortDirection, getPaginationItems, useToast };
